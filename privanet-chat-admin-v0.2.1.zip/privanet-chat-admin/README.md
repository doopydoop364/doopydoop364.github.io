# PrivaNet Chat Admin v0.2.1

A constrained conversational administration bridge for PrivaNet and PrivaSearch. It is designed to behave like a smart operations bot rather than a dashboard.

## What changed in v0.2.1

- Removes the unsupported `ConditionPathIsExecutable=` directive from the update-check helper unit.
- Reports `UPDATER_NOT_INSTALLED` and `UPDATER_CONFIG_MISSING` directly before invoking systemd.
- Deployment now warns when the Core updater executable or updater config is missing.
- Retains all v0.2.0 diagnostics, PrivaSearch, update, slot, audit, and allowlisted maintenance tools.
- Adds `get_system_health` for bounded homeserver uptime/load/memory/disk diagnostics.
- Adds PrivaSearch `/health` and authenticated `/status` tools for crawler/index/frontier health.
- Adds safe verified update checks and update execution through dedicated systemd units.
- Adds the known PrivaSearch systemd service to the default allowlist.
- Service restarts now verify that the unit returned to `active` before reporting success.
- Adds versioned application releases under `/opt/privanet-chat-admin/releases/` with an atomic `current` symlink.
- Adds `update.sh`, installed as `privanet-chat-admin-update`, for future one-command upgrades from GitHub Pages.
- Existing `/etc/privanet-chat-admin/config.json` files are migrated by adding only missing defaults; operator changes are preserved and backed up.

## Architecture

```text
ChatGPT
  |
  | OpenAI Secure MCP Tunnel
  v
127.0.0.1:8787/mcp
  |
  +-- PrivaNet admin CLI
  +-- systemd service/log inspection
  +-- local PrivaNode slot control
  +-- PrivaSearch loopback API
  +-- verified Priva application updater
  +-- bounded host diagnostics
```

The MCP process remains bound to localhost. No router port forwarding or VPN is required when using OpenAI Secure MCP Tunnel.

## Security model

- Binds only to `127.0.0.1:8787` by default.
- Exposes explicit MCP tools; **no arbitrary shell tool exists**.
- Subprocesses use exact argv arrays and never `shell=True`.
- The subprocess environment is deliberately small and uses an explicit PATH that includes `/opt/node/bin`.
- Service control is restricted to a root-owned allowlist.
- Node references, request codes, labels, capabilities, journal priorities, line counts, and slot counts are validated/bounded.
- Logs are bounded and common credential patterns are redacted.
- Mutations are written to a local SQLite audit log.
- PrivaSearch requests are restricted to a loopback HTTP origin. Redirects are refused.
- The PrivaSearch bearer token is read from the root-owned PrivaSearch environment file and is never returned by a tool.
- The MCP service keeps `ProtectSystem=strict`; updater checks/installs execute through purpose-built systemd units with their own narrow write allowlists.
- There are no generic file, shell, wipe, reset, or delete-state tools.

The service currently runs as root because the PrivaNet admin wrapper reads root-owned coordinator configuration and because service management/journal access require host privileges. The exposed tool surface remains allowlisted.

## Install / upgrade manually

From an extracted release directory:

```bash
cd privanet-chat-admin
chmod +x deploy.sh
sudo ./deploy.sh
sudo systemctl enable --now privanet-chat-admin
```

The local MCP endpoint is:

```text
http://127.0.0.1:8787/mcp
```

Existing v0.1 installs are migrated automatically. The deploy script leaves the old `/opt/privanet-chat-admin/app` directory untouched but switches the systemd unit to the versioned `current` symlink.

## Easy future updates

v0.2.1 installs:

```text
/usr/local/bin/privanet-chat-admin-update
```

Check for a new Chat Admin release:

```bash
sudo privanet-chat-admin-update --check
```

Install the published release:

```bash
sudo privanet-chat-admin-update
```

The updater reads:

```text
https://doopydoop364.github.io/privanet-chat-admin-latest.json
```

The manifest contains a version, HTTPS ZIP URL, and SHA-256. The updater refuses non-`doopydoop364.github.io` download origins and refuses a checksum mismatch before extraction.

## MCP tools

### Read-only / diagnostic

- `get_services`
- `get_service_status`
- `get_recent_logs`
- `get_system_health`
- `get_nodes`
- `get_pending_nodes`
- `get_audit_log`
- `get_local_node_slots`
- `get_privasearch_health`
- `get_privasearch_status`
- `get_update_status`
- `get_update_schedule`

### Mutating

- `restart_service`
- `apply_available_updates`
- `approve_node`
- `deny_node`
- `revoke_node`
- `set_local_node_slots`
- `clear_local_node_slots`

## PrivaSearch integration

Defaults:

```text
API:      http://127.0.0.1:4020
env file: /etc/privasearch/privasearch.env
service:  privasearch.service
```

`get_privasearch_health` calls the public loopback `/health` endpoint. `get_privasearch_status` calls `/status` and, when present, reads `PRIVASEARCH_API_TOKEN` from the environment file to authenticate. The token never becomes tool output.

Current PrivaSearch `/status` can expose documents/index size, duplicates, links, frontier states, demand/public pending counts, recrawl state, operational outcomes/throughput, retry ages, failure summaries, and domain/family concentration depending on the installed PrivaSearch version.

## Priva application updater integration

`get_update_status` starts `privanet-chat-admin-update-check.service`, whose only command is:

```text
/usr/local/bin/privanet-update --check
```

`apply_available_updates` starts the existing `privanet-update.service`. It therefore keeps Core's checksum verification, backups, release symlink switching, service restarts, and rollback behavior instead of reimplementing those operations inside the MCP bridge.

The Chat Admin self-updater is separate: `privanet-chat-admin-update` updates this MCP bridge itself from the GitHub Pages release manifest.

## Important: node job slots are local

The current Core coordinator does not centrally set another node's job slots. Slot state lives on each node. Therefore the slot tools only affect the PrivaNode on the same machine as this MCP agent.

A saved slot change applies on the next node start. `PRIVANODE_JOB_SLOTS`, if explicitly set in the node environment, takes precedence over saved state.

## Validation

Run from the source directory:

```bash
python -m pytest -q
bash -n deploy.sh
bash -n update.sh
python -m compileall -q agent
```

The unit tests cover command allowlisting, exact CLI mappings, job-slot bounds, PATH handling, PrivaSearch token handling, updater helper invocation, bounded host diagnostics, and credential redaction.
