from pathlib import Path

import pytest

from agent.core import AdminBackend, CommandResult, Runner, redact


class FakeRunner:
    def __init__(self):
        self.calls = []
        self.responses = []

    def queue(self, result):
        self.responses.append(result)

    def run(self, argv, **kwargs):
        self.calls.append(argv)
        if self.responses:
            return self.responses.pop(0)
        return CommandResult(True, 0, "{}", "")


def cfg(tmp_path: Path):
    updater = tmp_path / "privanet-update"
    updater.write_text("#!/bin/sh\n")
    updater.chmod(0o755)
    updater_config = tmp_path / "updater.json"
    updater_config.write_text('{"version":1,"channel":"prerelease"}\n')
    env_file = tmp_path / "privasearch.env"
    env_file.write_text("PRIVASEARCH_API_TOKEN='test-secret-token-abcdefghijklmnopqrstuvwxyz'\n")
    return {
        "audit_db": str(tmp_path / "audit.sqlite3"),
        "local_node_state_dir": "/var/lib/privanet-node",
        "command_path": "/opt/node/bin:/usr/bin:/bin",
        "managed_services": {"coordinator": "privanet-coordinator.service", "search": "privasearch.service"},
        "executables": {
            "privanet_admin": "/usr/local/bin/privanet-admin",
            "privanet_node": "/opt/privanet-node/current/bin/privanet-node",
            "privanet_update": str(updater),
        },
        "privasearch": {"base_url": "http://127.0.0.1:4020", "env_file": str(env_file)},
        "updater": {"config_file": str(updater_config)},
        "diagnostic_paths": [str(tmp_path)],
        "limits": {"max_log_lines": 50, "max_job_slots": 16, "command_timeout_seconds": 1, "update_timeout_seconds": 2},
    }


def test_runner_default_path_contains_opt_node():
    assert "/opt/node/bin" in Runner().command_path.split(":")


def test_service_allowlist(tmp_path):
    b = AdminBackend(cfg(tmp_path), FakeRunner())
    with pytest.raises(ValueError):
        b.restart_service("sshd")


def test_restart_is_exact_systemctl_argv_and_verifies(tmp_path):
    r = FakeRunner()
    r.queue(CommandResult(True, 0, "", ""))
    r.queue(CommandResult(True, 0, "ActiveState=active\nSubState=running\n", ""))
    b = AdminBackend(cfg(tmp_path), r)
    out = b.restart_service("coordinator")
    assert out["ok"] is True
    assert r.calls[0] == ["systemctl", "restart", "privanet-coordinator.service"]


def test_pending_uses_current_requests_cli(tmp_path):
    r = FakeRunner()
    b = AdminBackend(cfg(tmp_path), r)
    b.list_pending_nodes()
    assert r.calls[-1] == ["/usr/local/bin/privanet-admin", "requests", "list", "--json"]


def test_approve_requires_explicit_capability_and_uses_current_cli(tmp_path):
    r = FakeRunner()
    b = AdminBackend(cfg(tmp_path), r)
    b.approve_node("ABCD-EF12", ["web.fetch.v1"], "crawler")
    assert r.calls[-1] == [
        "/usr/local/bin/privanet-admin", "approve", "ABCD-EF12",
        "--capabilities", "web.fetch.v1", "--label", "crawler", "--json"
    ]
    with pytest.raises(ValueError):
        b.approve_node("ABCD-EF12", [])


def test_revoke_uses_nodes_revoke_and_rejects_option_injection(tmp_path):
    r = FakeRunner()
    b = AdminBackend(cfg(tmp_path), r)
    b.revoke_node("node_12345678")
    assert r.calls[-1] == ["/usr/local/bin/privanet-admin", "nodes", "revoke", "node_12345678"]
    with pytest.raises(ValueError):
        b.revoke_node("--help")


def test_local_job_slots_are_absolute_and_bounded(tmp_path):
    r = FakeRunner()
    b = AdminBackend(cfg(tmp_path), r)
    b.set_local_node_slots(8)
    assert r.calls[-1] == [
        "/opt/privanet-node/current/bin/privanet-node", "slots", "set", "8", "--json", "--state-dir", "/var/lib/privanet-node"
    ]
    with pytest.raises(ValueError):
        b.set_local_node_slots(17)


def test_local_job_slots_show_and_clear(tmp_path):
    r = FakeRunner()
    b = AdminBackend(cfg(tmp_path), r)
    b.local_node_slots()
    assert r.calls[-1][1:4] == ["slots", "show", "--json"]
    b.clear_local_node_slots()
    assert r.calls[-1][1:4] == ["slots", "clear", "--json"]


def test_log_line_limit(tmp_path):
    r = FakeRunner()
    r.queue(CommandResult(True, 0, "hello", ""))
    b = AdminBackend(cfg(tmp_path), r)
    b.recent_logs("coordinator", 500)
    assert "50" in r.calls[-1]


def test_privasearch_status_uses_loopback_and_secret_header_without_returning_secret(tmp_path):
    seen = {}
    def fake_http(url, headers, timeout, max_bytes):
        seen.update(url=url, headers=headers)
        return {"ok": True, "http_status": 200, "data": {"frontier": {"PENDING": 12}}, "error": None}
    b = AdminBackend(cfg(tmp_path), FakeRunner(), fake_http)
    out = b.privasearch_status()
    assert seen["url"] == "http://127.0.0.1:4020/status"
    assert seen["headers"]["Authorization"].startswith("Bearer test-secret")
    assert "test-secret" not in str(out)


def test_privasearch_health_does_not_send_auth(tmp_path):
    seen = {}
    def fake_http(url, headers, timeout, max_bytes):
        seen.update(headers=headers)
        return {"ok": True, "http_status": 200, "data": {"status": "ok"}, "error": None}
    b = AdminBackend(cfg(tmp_path), FakeRunner(), fake_http)
    b.privasearch_health()
    assert "Authorization" not in seen["headers"]


def test_update_check_uses_fixed_helper_unit(tmp_path):
    r = FakeRunner()
    r.queue(CommandResult(True, 0, "", ""))
    r.queue(CommandResult(True, 0, "InvocationID=0123456789abcdef0123456789abcdef\nResult=success\nExecMainStatus=0\n", ""))
    r.queue(CommandResult(True, 0, '{"app":"core","code":"UP_TO_DATE"}\n', ""))
    b = AdminBackend(cfg(tmp_path), r)
    out = b.check_updates()
    assert out["ok"] is True
    assert r.calls[0] == ["systemctl", "start", "privanet-chat-admin-update-check.service"]
    assert out["events"][0]["code"] == "UP_TO_DATE"


def test_update_check_reports_missing_executable_before_systemd(tmp_path):
    config = cfg(tmp_path)
    Path(config["executables"]["privanet_update"]).unlink()
    r = FakeRunner()
    b = AdminBackend(config, r)
    out = b.check_updates()
    assert out["ok"] is False
    assert out["events"][0]["code"] == "UPDATER_NOT_INSTALLED"
    assert r.calls == []


def test_update_check_reports_missing_config_before_systemd(tmp_path):
    config = cfg(tmp_path)
    Path(config["updater"]["config_file"]).unlink()
    r = FakeRunner()
    b = AdminBackend(config, r)
    out = b.check_updates()
    assert out["ok"] is False
    assert out["events"][0]["code"] == "UPDATER_CONFIG_MISSING"
    assert r.calls == []


def test_system_health_is_bounded_to_configured_paths(tmp_path):
    b = AdminBackend(cfg(tmp_path), FakeRunner())
    out = b.system_health()
    assert out["ok"] is True
    assert str(tmp_path) in out["disks"]


def test_redaction():
    text = "Authorization: Bearer abc123 token=xyz password: hunter2"
    clean = redact(text)
    assert "abc123" not in clean
    assert "xyz" not in clean
    assert "hunter2" not in clean
