from __future__ import annotations

import json
import os
import re
import shlex
import shutil
import sqlite3
import subprocess
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

VERSION = "0.2.1"

SECRET_PATTERNS = [
    re.compile(r"(?i)(authorization:\s*bearer\s+)[^\s]+"),
    re.compile(r"(?i)(token|secret|password|api[_-]?key)(\s*[=:]\s*)[^\s,;]+"),
]


def redact(text: str) -> str:
    out = text
    for pattern in SECRET_PATTERNS:
        if pattern.groups >= 2:
            out = pattern.sub(lambda m: f"{m.group(1)}{m.group(2)}[REDACTED]", out)
        else:
            out = pattern.sub(lambda m: f"{m.group(1)}[REDACTED]", out)
    return out


@dataclass(frozen=True)
class CommandResult:
    ok: bool
    code: int
    stdout: str
    stderr: str


class Runner:
    """Exact-argv subprocess runner with a deliberately small environment."""

    def __init__(self, timeout: int = 20, command_path: str | None = None):
        self.timeout = timeout
        self.command_path = command_path or "/opt/node/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"

    def run(self, argv: list[str], timeout: int | None = None) -> CommandResult:
        proc = subprocess.run(
            argv,
            text=True,
            capture_output=True,
            timeout=timeout or self.timeout,
            check=False,
            env={"PATH": self.command_path, "LANG": "C.UTF-8"},
        )
        return CommandResult(
            ok=proc.returncode == 0,
            code=proc.returncode,
            stdout=redact(proc.stdout[-40000:]),
            stderr=redact(proc.stderr[-20000:]),
        )


class AuditLog:
    def __init__(self, db_path: str):
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        self.db_path = db_path
        with sqlite3.connect(self.db_path) as db:
            db.execute(
                """
                CREATE TABLE IF NOT EXISTS audit (
                  id INTEGER PRIMARY KEY AUTOINCREMENT,
                  ts INTEGER NOT NULL,
                  action TEXT NOT NULL,
                  target TEXT,
                  args_json TEXT NOT NULL,
                  ok INTEGER NOT NULL,
                  summary TEXT NOT NULL
                )
                """
            )

    def write(self, action: str, target: str | None, args: dict[str, Any], ok: bool, summary: str) -> None:
        safe_args = {
            k: ("[REDACTED]" if any(s in k.lower() for s in ("token", "secret", "password", "key")) else v)
            for k, v in args.items()
        }
        with sqlite3.connect(self.db_path) as db:
            db.execute(
                "INSERT INTO audit(ts,action,target,args_json,ok,summary) VALUES(?,?,?,?,?,?)",
                (int(time.time()), action, target, json.dumps(safe_args, sort_keys=True), int(ok), redact(summary)[:4000]),
            )

    def recent(self, limit: int = 50) -> list[dict[str, Any]]:
        limit = max(1, min(limit, 200))
        with sqlite3.connect(self.db_path) as db:
            rows = db.execute(
                "SELECT ts,action,target,args_json,ok,summary FROM audit ORDER BY id DESC LIMIT ?",
                (limit,),
            ).fetchall()
        return [
            {
                "ts": row[0],
                "action": row[1],
                "target": row[2],
                "args": json.loads(row[3]),
                "ok": bool(row[4]),
                "summary": row[5],
            }
            for row in rows
        ]


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):  # type: ignore[override]
        raise urllib.error.HTTPError(req.full_url, code, "redirect refused", headers, fp)


def _default_http_json(url: str, headers: dict[str, str], timeout: float, max_bytes: int) -> dict[str, Any]:
    parsed = urllib.parse.urlsplit(url)
    if parsed.scheme != "http" or parsed.hostname not in {"127.0.0.1", "localhost", "::1"}:
        raise ValueError("PrivaSearch URL must be loopback HTTP")
    request = urllib.request.Request(url, headers=headers, method="GET")
    opener = urllib.request.build_opener(_NoRedirect())
    try:
        with opener.open(request, timeout=timeout) as response:
            raw = response.read(max_bytes + 1)
            if len(raw) > max_bytes:
                raise ValueError("PrivaSearch response too large")
            return {
                "ok": 200 <= response.status < 300,
                "http_status": response.status,
                "data": json.loads(raw.decode("utf-8")),
                "error": None,
            }
    except urllib.error.HTTPError as exc:
        raw = exc.read(min(max_bytes, 8192)) if exc.fp else b""
        body = redact(raw.decode("utf-8", errors="replace"))
        return {"ok": False, "http_status": exc.code, "data": None, "error": body or str(exc.reason)}
    except (urllib.error.URLError, TimeoutError, OSError, json.JSONDecodeError, ValueError) as exc:
        return {"ok": False, "http_status": None, "data": None, "error": redact(str(exc))}


class AdminBackend:
    """Allowlisted PrivaNet administration. No generic shell execution exists."""

    def __init__(
        self,
        config: dict[str, Any],
        runner: Runner | None = None,
        http_json: Callable[[str, dict[str, str], float, int], dict[str, Any]] | None = None,
    ):
        self.config = config
        self.services: dict[str, str] = config.get("managed_services", {})
        executables = config.get("executables", {})
        self.admin_bin = executables.get("privanet_admin", "/usr/local/bin/privanet-admin")
        self.node_bin = executables.get("privanet_node", "/opt/privanet-node/current/bin/privanet-node")
        self.updater_bin = executables.get("privanet_update", "/usr/local/bin/privanet-update")
        updater = config.get("updater", {})
        self.updater_config_file = str(updater.get("config_file", "/etc/privanet/updater.json"))
        self.node_state_dir = config.get("local_node_state_dir", "/var/lib/privanet-node")
        limits = config.get("limits", {})
        self.max_log_lines = int(limits.get("max_log_lines", 300))
        self.max_job_slots = int(limits.get("max_job_slots", 32))
        self.update_timeout = int(limits.get("update_timeout_seconds", 7200))
        self.http_timeout = float(limits.get("http_timeout_seconds", 5))
        self.http_max_bytes = int(limits.get("http_max_bytes", 2 * 1024 * 1024))
        command_path = config.get(
            "command_path",
            "/opt/node/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
        )
        self.runner = runner or Runner(int(limits.get("command_timeout_seconds", 20)), command_path)
        self.audit = AuditLog(config.get("audit_db", "/var/lib/privanet-chat-admin/audit.sqlite3"))
        search = config.get("privasearch", {})
        self.search_base_url = str(search.get("base_url", "http://127.0.0.1:4020")).rstrip("/")
        self.search_env_file = str(search.get("env_file", "/etc/privasearch/privasearch.env"))
        self.http_json = http_json or _default_http_json
        self.diagnostic_paths = [str(p) for p in config.get("diagnostic_paths", ["/", "/var", "/opt"])]

    @staticmethod
    def _json_or_text(result: CommandResult) -> Any:
        if not result.ok:
            return None
        try:
            return json.loads(result.stdout)
        except json.JSONDecodeError:
            return result.stdout

    @staticmethod
    def _json_lines(text: str) -> list[Any]:
        rows: list[Any] = []
        for line in text.splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                rows.append(json.loads(line))
            except json.JSONDecodeError:
                rows.append({"message": redact(line)})
        return rows

    @staticmethod
    def _node_reference(reference: str) -> str:
        value = reference.strip()
        if not value or len(value) > 160 or value.startswith("-") or not re.fullmatch(r"[A-Za-z0-9_.:@+\- ]+", value):
            raise ValueError("Invalid node reference")
        return value

    @staticmethod
    def _request_code(request_code: str) -> str:
        value = request_code.strip().upper().replace(" ", "-")
        if not re.fullmatch(r"[A-Z0-9]{4}-?[A-Z0-9]{4}", value):
            raise ValueError("Invalid request code format")
        if "-" not in value:
            value = f"{value[:4]}-{value[4:]}"
        return value

    @staticmethod
    def _capabilities(capabilities: list[str]) -> list[str]:
        if not capabilities:
            raise ValueError("At least one capability is required")
        clean: list[str] = []
        for capability in capabilities:
            value = capability.strip()
            if not re.fullmatch(r"[a-z0-9][a-z0-9._-]{0,95}", value):
                raise ValueError(f"Invalid capability: {capability}")
            if value not in clean:
                clean.append(value)
        return clean

    def _service(self, name: str) -> str:
        try:
            return self.services[name]
        except KeyError:
            raise ValueError(f"Unknown managed service: {name}") from None

    @staticmethod
    def _read_env_value(path: str, key: str) -> str | None:
        try:
            text = Path(path).read_text(encoding="utf-8")
        except (FileNotFoundError, PermissionError, OSError):
            return None
        for raw in text.splitlines():
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("export "):
                line = line[7:].lstrip()
            if "=" not in line:
                continue
            name, value = line.split("=", 1)
            if name.strip() != key:
                continue
            value = value.strip()
            try:
                parsed = shlex.split(value, posix=True)
                return parsed[0] if len(parsed) == 1 else value.strip("'\"")
            except ValueError:
                return value.strip("'\"")
        return None

    def _search_headers(self) -> dict[str, str]:
        headers = {"Accept": "application/json", "User-Agent": f"PrivaNet-Chat-Admin/{VERSION}"}
        token = self._read_env_value(self.search_env_file, "PRIVASEARCH_API_TOKEN")
        if token:
            headers["Authorization"] = f"Bearer {token}"
        return headers

    def _search_get(self, path: str, authenticated: bool) -> dict[str, Any]:
        if path not in {"/health", "/status"}:
            raise ValueError("Unsupported PrivaSearch path")
        headers = self._search_headers() if authenticated else {"Accept": "application/json", "User-Agent": f"PrivaNet-Chat-Admin/{VERSION}"}
        result = self.http_json(self.search_base_url + path, headers, self.http_timeout, self.http_max_bytes)
        if isinstance(result.get("error"), str):
            result["error"] = redact(result["error"])
        return result

    def service_status(self, name: str) -> dict[str, Any]:
        unit = self._service(name)
        result = self.runner.run([
            "systemctl", "show", unit, "--no-page",
            "--property=ActiveState,SubState,MainPID,ExecMainStatus,ActiveEnterTimestamp,Result",
        ])
        data: dict[str, str] = {}
        for line in result.stdout.splitlines():
            if "=" in line:
                k, v = line.split("=", 1)
                data[k] = v
        return {"service": name, "unit": unit, "ok": result.ok, "state": data, "error": result.stderr or None}

    def list_services(self) -> list[dict[str, Any]]:
        return [self.service_status(name) for name in sorted(self.services)]

    def recent_logs(self, name: str, lines: int = 100, priority: str | None = None) -> dict[str, Any]:
        unit = self._service(name)
        lines = max(1, min(int(lines), self.max_log_lines))
        argv = ["journalctl", "-u", unit, "-n", str(lines), "--no-pager", "--output=short-iso"]
        if priority:
            allowed = {"emerg", "alert", "crit", "err", "warning", "notice", "info", "debug"}
            if priority not in allowed:
                raise ValueError("Unsupported journal priority")
            argv += ["-p", priority]
        result = self.runner.run(argv)
        return {"service": name, "ok": result.ok, "logs": result.stdout, "error": result.stderr or None}

    def restart_service(self, name: str) -> dict[str, Any]:
        unit = self._service(name)
        result = self.runner.run(["systemctl", "restart", unit])
        status = self.service_status(name)
        ok = result.ok and status.get("state", {}).get("ActiveState") == "active"
        self.audit.write("restart_service", name, {}, ok, result.stderr or json.dumps(status.get("state", {})))
        return {"service": name, "ok": ok, "state": status.get("state"), "error": result.stderr or status.get("error")}

    def list_nodes(self) -> dict[str, Any]:
        result = self.runner.run([self.admin_bin, "nodes", "list", "--json"])
        return {"ok": result.ok, "nodes": self._json_or_text(result), "error": result.stderr or None}

    def list_pending_nodes(self, include_all: bool = False) -> dict[str, Any]:
        argv = [self.admin_bin, "requests", "list"]
        if include_all:
            argv.append("--all")
        argv.append("--json")
        result = self.runner.run(argv)
        return {"ok": result.ok, "pending": self._json_or_text(result), "error": result.stderr or None}

    def approve_node(self, request_code: str, capabilities: list[str], label: str | None = None) -> dict[str, Any]:
        code = self._request_code(request_code)
        caps = self._capabilities(capabilities)
        argv = [self.admin_bin, "approve", code, "--capabilities", ",".join(caps)]
        if label is not None:
            clean_label = label.strip()
            if not clean_label or len(clean_label) > 80 or any(ord(ch) < 32 for ch in clean_label):
                raise ValueError("Invalid node label")
            argv += ["--label", clean_label]
        argv.append("--json")
        result = self.runner.run(argv)
        self.audit.write("approve_node", code, {"capabilities": caps, "label": label}, result.ok, result.stderr or result.stdout)
        return {"ok": result.ok, "request_code": code, "capabilities": caps, "label": label, "output": self._json_or_text(result), "error": result.stderr or None}

    def deny_node(self, request_code: str) -> dict[str, Any]:
        code = self._request_code(request_code)
        result = self.runner.run([self.admin_bin, "deny", code, "--json"])
        self.audit.write("deny_node", code, {}, result.ok, result.stderr or result.stdout)
        return {"ok": result.ok, "request_code": code, "output": self._json_or_text(result), "error": result.stderr or None}

    def revoke_node(self, node_reference: str) -> dict[str, Any]:
        reference = self._node_reference(node_reference)
        result = self.runner.run([self.admin_bin, "nodes", "revoke", reference])
        self.audit.write("revoke_node", reference, {}, result.ok, result.stderr or result.stdout)
        return {"ok": result.ok, "node_reference": reference, "output": result.stdout, "error": result.stderr or None}

    def local_node_slots(self) -> dict[str, Any]:
        result = self.runner.run([self.node_bin, "slots", "show", "--json", "--state-dir", self.node_state_dir])
        return {"ok": result.ok, "slots": self._json_or_text(result), "error": result.stderr or None}

    def set_local_node_slots(self, slots: int) -> dict[str, Any]:
        slots = int(slots)
        if slots < 1 or slots > self.max_job_slots:
            raise ValueError(f"slots must be between 1 and {self.max_job_slots}")
        result = self.runner.run([self.node_bin, "slots", "set", str(slots), "--json", "--state-dir", self.node_state_dir])
        parsed = self._json_or_text(result)
        self.audit.write("set_local_node_slots", "local-node", {"slots": slots}, result.ok, result.stderr or result.stdout)
        return {"ok": result.ok, "slots": slots, "result": parsed, "note": "The saved slot count applies at the node's next start and PRIVANODE_JOB_SLOTS, if set, takes priority.", "error": result.stderr or None}

    def clear_local_node_slots(self) -> dict[str, Any]:
        result = self.runner.run([self.node_bin, "slots", "clear", "--json", "--state-dir", self.node_state_dir])
        self.audit.write("clear_local_node_slots", "local-node", {}, result.ok, result.stderr or result.stdout)
        return {"ok": result.ok, "result": self._json_or_text(result), "error": result.stderr or None}

    def privasearch_health(self) -> dict[str, Any]:
        return self._search_get("/health", authenticated=False)

    def privasearch_status(self) -> dict[str, Any]:
        return self._search_get("/status", authenticated=True)

    def system_health(self) -> dict[str, Any]:
        uptime_sec: float | None = None
        try:
            uptime_sec = float(Path("/proc/uptime").read_text().split()[0])
        except (OSError, ValueError, IndexError):
            pass

        memory: dict[str, int] = {}
        try:
            for line in Path("/proc/meminfo").read_text().splitlines():
                if ":" not in line:
                    continue
                key, value = line.split(":", 1)
                pieces = value.strip().split()
                if pieces and pieces[0].isdigit():
                    multiplier = 1024 if len(pieces) > 1 and pieces[1].lower() == "kb" else 1
                    memory[key] = int(pieces[0]) * multiplier
        except OSError:
            pass

        disks: dict[str, Any] = {}
        for raw in self.diagnostic_paths[:16]:
            path = Path(raw)
            if not path.is_absolute() or ".." in path.parts or not path.exists():
                continue
            try:
                usage = shutil.disk_usage(path)
                disks[str(path)] = {"totalBytes": usage.total, "usedBytes": usage.used, "freeBytes": usage.free}
            except OSError:
                continue

        try:
            load = list(os.getloadavg())
        except OSError:
            load = []
        return {
            "ok": True,
            "bridgeVersion": VERSION,
            "hostname": os.uname().nodename,
            "uptimeSec": uptime_sec,
            "loadAverage": load,
            "cpuCount": os.cpu_count(),
            "memory": {
                "totalBytes": memory.get("MemTotal"),
                "availableBytes": memory.get("MemAvailable"),
                "freeBytes": memory.get("MemFree"),
                "swapTotalBytes": memory.get("SwapTotal"),
                "swapFreeBytes": memory.get("SwapFree"),
            },
            "disks": disks,
        }

    def updater_schedule(self) -> dict[str, Any]:
        result = self.runner.run([
            "systemctl", "show", "privanet-update.timer", "--no-page",
            "--property=LoadState,ActiveState,SubState,LastTriggerUSec,NextElapseUSecRealtime",
        ])
        data: dict[str, str] = {}
        for line in result.stdout.splitlines():
            if "=" in line:
                key, value = line.split("=", 1)
                data[key] = value
        return {"ok": result.ok, "timer": data, "error": result.stderr or None}

    def _capture_systemd_invocation(self, unit: str, start_timeout: int) -> dict[str, Any]:
        if not re.fullmatch(r"[A-Za-z0-9_.@-]+\.service", unit):
            raise ValueError("Invalid systemd unit")
        started = self.runner.run(["systemctl", "start", unit], timeout=start_timeout)
        props = self.runner.run([
            "systemctl", "show", unit, "--no-page",
            "--property=InvocationID,Result,ExecMainStatus,ActiveState,SubState",
        ])
        values: dict[str, str] = {}
        for line in props.stdout.splitlines():
            if "=" in line:
                key, value = line.split("=", 1)
                values[key] = value
        invocation = values.get("InvocationID", "")
        logs = CommandResult(True, 0, "", "")
        if re.fullmatch(r"[0-9a-fA-F]{32}", invocation):
            logs = self.runner.run([
                "journalctl", f"_SYSTEMD_INVOCATION_ID={invocation}", "--no-pager", "--output=cat", "-n", "500"
            ])
        else:
            logs = self.runner.run(["journalctl", "-u", unit, "--no-pager", "--output=cat", "-n", "100"])
        ok = started.ok and values.get("Result") in {"success", ""} and values.get("ExecMainStatus") in {"0", ""}
        return {
            "ok": ok,
            "unit": unit,
            "state": values,
            "events": self._json_lines(logs.stdout),
            "error": started.stderr or props.stderr or logs.stderr or None,
        }

    def _updater_prerequisite_error(self) -> dict[str, Any] | None:
        updater = Path(self.updater_bin)
        if not updater.is_file() or not os.access(updater, os.X_OK):
            return {
                "ok": False,
                "events": [{"app": "all", "code": "UPDATER_NOT_INSTALLED"}],
                "error": f"Updater executable is missing or not executable at {self.updater_bin}",
            }
        config = Path(self.updater_config_file)
        if not config.is_file():
            return {
                "ok": False,
                "events": [{"app": "all", "code": "UPDATER_CONFIG_MISSING"}],
                "error": f"Updater config not found at {self.updater_config_file}",
            }
        return None

    def check_updates(self) -> dict[str, Any]:
        prerequisite = self._updater_prerequisite_error()
        if prerequisite is not None:
            return prerequisite
        return self._capture_systemd_invocation("privanet-chat-admin-update-check.service", self.update_timeout)

    def apply_updates(self) -> dict[str, Any]:
        prerequisite = self._updater_prerequisite_error()
        if prerequisite is not None:
            return prerequisite
        result = self._capture_systemd_invocation("privanet-update.service", self.update_timeout)
        self.audit.write("apply_updates", "priva-apps", {}, result.get("ok", False), json.dumps(result.get("events", []))[:4000])
        return result

    def audit_recent(self, limit: int = 50) -> list[dict[str, Any]]:
        return self.audit.recent(limit)
