#!/usr/bin/env bash
set -euo pipefail

VERSION=0.2.1
PREFIX=${PREFIX:-/opt/privanet-chat-admin}
CONFIG_DIR=${CONFIG_DIR:-/etc/privanet-chat-admin}
STATE_DIR=${STATE_DIR:-/var/lib/privanet-chat-admin}
RELEASE_DIR="$PREFIX/releases/$VERSION"
CURRENT_LINK="$PREFIX/current"
COMMAND_PATH=/opt/node/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin

if [[ $EUID -ne 0 ]]; then
  echo "Run as root." >&2
  exit 1
fi

for cmd in python3 systemctl install; do
  command -v "$cmd" >/dev/null 2>&1 || { echo "Missing required command: $cmd" >&2; exit 1; }
done

WAS_ACTIVE=0
if systemctl is-active --quiet privanet-chat-admin.service 2>/dev/null; then
  WAS_ACTIVE=1
fi
PREVIOUS_TARGET=""
if [[ -L "$CURRENT_LINK" ]]; then
  PREVIOUS_TARGET=$(readlink -f "$CURRENT_LINK" || true)
fi

install -d -m 0755 "$PREFIX" "$PREFIX/releases" "$CONFIG_DIR"
install -d -o root -g root -m 0700 "$STATE_DIR" "$STATE_DIR/backups"

if [[ ! -x "$PREFIX/venv/bin/python" ]]; then
  python3 -m venv "$PREFIX/venv"
fi
"$PREFIX/venv/bin/pip" install --upgrade pip
"$PREFIX/venv/bin/pip" install 'mcp>=2,<3' 'pydantic>=2.10,<3' 'uvicorn>=0.30,<1'

rm -rf "$RELEASE_DIR.tmp"
install -d -m 0755 "$RELEASE_DIR.tmp/app/agent"
install -m 0644 agent/__init__.py agent/core.py agent/server.py "$RELEASE_DIR.tmp/app/agent/"
printf '%s\n' "$VERSION" > "$RELEASE_DIR.tmp/VERSION"
chmod 0644 "$RELEASE_DIR.tmp/VERSION"
rm -rf "$RELEASE_DIR"
mv "$RELEASE_DIR.tmp" "$RELEASE_DIR"

if [[ ! -e "$CONFIG_DIR/config.json" ]]; then
  install -m 0600 -o root -g root agent/config.example.json "$CONFIG_DIR/config.json"
  echo "Created $CONFIG_DIR/config.json"
else
  cp -a "$CONFIG_DIR/config.json" "$STATE_DIR/backups/config-pre-$VERSION-$(date +%Y%m%d-%H%M%S).json"
  python3 - "$CONFIG_DIR/config.json" agent/config.example.json <<'PY'
import json, os, sys, tempfile
current_path, defaults_path = sys.argv[1:]
with open(current_path, encoding='utf-8') as f:
    current = json.load(f)
with open(defaults_path, encoding='utf-8') as f:
    defaults = json.load(f)

def merge(dst, src):
    for key, value in src.items():
        if key not in dst:
            dst[key] = value
        elif isinstance(dst[key], dict) and isinstance(value, dict):
            merge(dst[key], value)
merge(current, defaults)
fd, tmp = tempfile.mkstemp(prefix='.config.', dir=os.path.dirname(current_path), text=True)
try:
    with os.fdopen(fd, 'w', encoding='utf-8') as f:
        json.dump(current, f, indent=2, sort_keys=False)
        f.write('\n')
    os.chmod(tmp, 0o600)
    os.replace(tmp, current_path)
finally:
    if os.path.exists(tmp):
        os.unlink(tmp)
PY
fi
chmod 0600 "$CONFIG_DIR/config.json"
chown root:root "$CONFIG_DIR/config.json"

if [[ -f update.sh ]]; then
  install -m 0755 -o root -g root update.sh /usr/local/bin/privanet-chat-admin-update
fi

cat > /etc/systemd/system/privanet-chat-admin.service <<UNIT
[Unit]
Description=PrivaNet conversational admin MCP service (LOCALHOST ONLY)
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=root
Group=root
WorkingDirectory=$CURRENT_LINK/app
Environment=PYTHONPATH=$CURRENT_LINK/app
Environment=PRIVANET_CHAT_ADMIN_CONFIG=$CONFIG_DIR/config.json
Environment="PATH=$COMMAND_PATH"
ExecStart=$PREFIX/venv/bin/uvicorn agent.server:app --host 127.0.0.1 --port 8787
Restart=on-failure
RestartSec=5
NoNewPrivileges=true
PrivateTmp=true
PrivateDevices=true
ProtectHome=true
ProtectSystem=strict
ReadWritePaths=$STATE_DIR
ProtectKernelTunables=true
ProtectKernelModules=true
ProtectControlGroups=true
RestrictAddressFamilies=AF_INET AF_INET6 AF_UNIX
RestrictRealtime=true
LockPersonality=true
RestrictSUIDSGID=true

[Install]
WantedBy=multi-user.target
UNIT

# Read-only update check helper. It runs outside the MCP service's stricter
# filesystem namespace but uses the same updater sandbox as PrivaNet Core.
if [[ ! -x /usr/local/bin/privanet-update ]]; then
  echo "Warning: /usr/local/bin/privanet-update is missing or not executable; update tools will report UPDATER_NOT_INSTALLED." >&2
fi
if [[ ! -f /etc/privanet/updater.json ]]; then
  echo "Warning: /etc/privanet/updater.json is missing; update tools will report UPDATER_CONFIG_MISSING." >&2
fi
cat > /etc/systemd/system/privanet-chat-admin-update-check.service <<'UNIT'
[Unit]
Description=Check verified Priva application releases for Chat Admin
After=network-online.target
Wants=network-online.target
ConditionPathExists=/etc/privanet/updater.json

[Service]
Type=oneshot
ExecStart=/usr/local/bin/privanet-update --check
User=root
Group=root
UMask=0077
TimeoutStartSec=2h
Environment=PATH=/opt/node/bin:/usr/local/bin:/usr/bin:/bin
NoNewPrivileges=yes
PrivateTmp=yes
PrivateDevices=yes
ProtectHome=yes
ProtectSystem=strict
ReadWritePaths=/opt /var/lib/privanet-updater /run
RestrictAddressFamilies=AF_INET AF_INET6 AF_UNIX
ProtectKernelTunables=yes
ProtectControlGroups=yes
UNIT

ln -sfnT "$RELEASE_DIR" "$CURRENT_LINK"
systemctl daemon-reload

if [[ $WAS_ACTIVE -eq 1 ]]; then
  if ! systemctl restart privanet-chat-admin.service || ! systemctl is-active --quiet privanet-chat-admin.service; then
    echo "New release failed to start; attempting rollback." >&2
    if [[ -n "$PREVIOUS_TARGET" && -d "$PREVIOUS_TARGET" ]]; then
      ln -sfnT "$PREVIOUS_TARGET" "$CURRENT_LINK"
      systemctl daemon-reload
      systemctl restart privanet-chat-admin.service || true
    fi
    exit 1
  fi
  echo "Updated and restarted privanet-chat-admin.service to $VERSION"
else
  echo "Installed PrivaNet Chat Admin $VERSION. Start with: systemctl enable --now privanet-chat-admin"
fi

echo "Updater command: privanet-chat-admin-update"
