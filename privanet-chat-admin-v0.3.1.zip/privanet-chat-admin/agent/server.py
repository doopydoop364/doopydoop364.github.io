from __future__ import annotations

import json
import os
import secrets
import weakref
from typing import Any, Literal

from mcp.server import MCPServer
from mcp.server.apps import Apps
from mcp.server.mcpserver.context import Context
from mcp.server.mcpserver.resources import TextResource

from .core import AdminBackend, BrokerError, SCOPES, VERSION

CONFIG_PATH = os.environ.get("PRIVANET_CHAT_ADMIN_CONFIG", "/etc/privanet-chat-admin/config.json")
with open(CONFIG_PATH, "r", encoding="utf-8") as fh:
    config = json.load(fh)
backend = AdminBackend(config)

_SESSION_KEYS: weakref.WeakKeyDictionary[Any, str] = weakref.WeakKeyDictionary()


def _session_key(context: Context[Any, Any]) -> str:
    session = context.request_context.session
    try:
        key = _SESSION_KEYS.get(session)
        if key is None:
            key = "mcp_" + secrets.token_hex(16)
            _SESSION_KEYS[session] = key
        return key
    except TypeError:
        return "mcp_" + format(id(session), "x")


def _ensure_scope(context: Context[Any, Any], scope: str, reason: str) -> tuple[bool, dict[str, Any]]:
    session_key = _session_key(context)
    status = backend.authorization_status(session_key)
    if any(lease.get("scope") == scope for lease in status.get("leases", [])):
        return True, {"authorization": "existing", "scope": scope}
    return False, {
        "ok": False,
        "code": "AUTHORIZATION_REQUIRED",
        "scope": scope,
        "reason": reason,
        "allows": SCOPES[scope],
        "nextTool": "request_admin_access",
        "message": "Open the PrivaNet approval card with request_admin_access, then retry this action after the user approves it.",
    }


APP_URI = "ui://privanet-admin/approval-v1.html"
APP_HTML = r'''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>PrivaNet Admin Approval</title>
<style>
:root{font-family:ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;color-scheme:light dark}
*{box-sizing:border-box} body{margin:0;padding:12px;background:transparent;color:inherit}.card{border:1px solid color-mix(in srgb,currentColor 18%,transparent);border-radius:16px;padding:16px;max-width:620px;background:color-mix(in srgb,Canvas 96%,transparent);box-shadow:0 4px 18px rgba(0,0,0,.06)}
.head{display:flex;gap:10px;align-items:center;margin-bottom:12px}.badge{font-size:12px;font-weight:700;padding:4px 8px;border-radius:999px;background:color-mix(in srgb,#6b5cff 18%,transparent)}h2{font-size:17px;margin:0}.muted{opacity:.72;font-size:13px;line-height:1.45}.scope{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:12px;padding:8px 10px;border-radius:10px;background:color-mix(in srgb,currentColor 7%,transparent);overflow-wrap:anywhere}.reason{margin:12px 0;line-height:1.45}.choices{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;margin:12px 0}.choices label{border:1px solid color-mix(in srgb,currentColor 16%,transparent);border-radius:10px;padding:9px;font-size:13px;cursor:pointer}.actions{display:flex;gap:8px;justify-content:flex-end;margin-top:14px}button{border:0;border-radius:10px;padding:9px 13px;font-weight:650;cursor:pointer}button.primary{background:#6b5cff;color:white}button.secondary{background:color-mix(in srgb,currentColor 10%,transparent);color:inherit}button:disabled{opacity:.5;cursor:not-allowed}.status{margin-top:10px;font-size:13px;min-height:18px}.danger{background:color-mix(in srgb,#d33 15%,transparent)}
@media(max-width:480px){.choices{grid-template-columns:1fr}.actions{flex-direction:column-reverse}button{width:100%}}
</style>
</head>
<body>
<div class="card" id="card">
  <div class="head"><span class="badge">PrivaNet Admin</span><h2 id="title">Permission request</h2></div>
  <div class="scope" id="scope">Loading request…</div>
  <div class="reason" id="reason"></div>
  <div class="muted" id="details"></div>
  <div class="choices" id="choices"></div>
  <div class="actions"><button class="secondary" id="deny">Deny</button><button class="primary" id="approve">Approve</button></div>
  <div class="status" id="status"></div>
</div>
<script>
(() => {
  const $ = id => document.getElementById(id);
  let payload = null;
  const extract = value => {
    if (!value) return null;
    if (value.structuredContent && typeof value.structuredContent === 'object') return value.structuredContent;
    if (typeof value === 'object' && (value.kind || value.requestId)) return value;
    const content = value.content || value?.mcp_tool_result?.content;
    if (Array.isArray(content)) {
      const text = content.find(x => x && x.type === 'text' && typeof x.text === 'string')?.text;
      if (text) { try { return JSON.parse(text); } catch {} }
    }
    return null;
  };
  const current = () => extract(window.openai?.toolOutput) || extract(window.openai?.toolResponseMetadata?.mcp_tool_result);
  const setBusy = busy => { $('approve').disabled = busy; $('deny').disabled = busy; };
  const call = async (name, args) => {
    if (!window.openai?.callTool) throw new Error('This ChatGPT client does not expose widget tool calls.');
    return extract(await window.openai.callTool(name, args));
  };
  const followUp = async text => {
    if (window.openai?.sendFollowUpMessage) await window.openai.sendFollowUpMessage({prompt:text,scrollToBottom:true});
  };
  const render = () => {
    const next = current(); if (next) payload = next;
    if (!payload) { $('status').textContent='Waiting for request data…'; setBusy(true); return; }
    setBusy(false);
    const destructive = payload.kind === 'confirmation';
    $('title').textContent = destructive ? 'Confirm sensitive action' : 'Administrative access request';
    $('card').classList.toggle('danger', destructive);
    $('scope').textContent = destructive ? `${payload.action} · ${payload.target}` : payload.scope;
    $('reason').textContent = payload.reason || '';
    $('details').textContent = destructive
      ? 'This confirmation is valid for this exact action and target once.'
      : `${payload.allows || ''} The command sandbox remains the unprivileged privanet-shell account; this does not enable a root shell.`;
    const box=$('choices'); box.innerHTML='';
    if (!destructive) {
      [['once','This action only'],['15m','15 minutes'],['30m','30 minutes'],['60m','1 hour']].forEach(([v,label],i)=>{
        const el=document.createElement('label');
        el.innerHTML=`<input type="radio" name="duration" value="${v}" ${i===0?'checked':''}> ${label}`; box.appendChild(el);
      });
    }
  };
  $('approve').addEventListener('click', async () => {
    if (!payload) return; setBusy(true); $('status').textContent='Approving…';
    try {
      let result;
      if (payload.kind === 'confirmation') {
        result = await call('grant_action_confirmation',{request_id:payload.requestId});
      } else {
        const duration=document.querySelector('input[name="duration"]:checked')?.value || 'once';
        result = await call('grant_admin_access',{request_id:payload.requestId,duration});
      }
      if (!result?.ok) throw new Error(result?.error || result?.message || 'Approval was not granted.');
      $('status').textContent='Approved. ChatGPT can retry the requested PrivaNet action.';
      $('approve').disabled=true; $('deny').disabled=true;
      await followUp(payload.followUp || 'PrivaNet approval was granted. Retry the operation that required authorization and verify the result.');
    } catch (e) { $('status').textContent=`Approval failed: ${e?.message || e}`; setBusy(false); }
  });
  $('deny').addEventListener('click', async () => {
    if (!payload) return; setBusy(true); $('status').textContent='Denying…';
    try {
      const name=payload.kind==='confirmation'?'deny_action_confirmation':'deny_admin_access';
      const result=await call(name,{request_id:payload.requestId});
      if (!result?.ok) throw new Error(result?.error || result?.message || 'Denial failed.');
      $('status').textContent='Denied. No privileged action was performed.';
      $('approve').disabled=true; $('deny').disabled=true;
    } catch (e) { $('status').textContent=`Could not record denial: ${e?.message || e}`; setBusy(false); }
  });
  window.addEventListener('openai:set_globals', render, {passive:true});
  render(); setTimeout(render,100);
})();
</script>
</body>
</html>'''

apps = Apps()


@apps.tool(
    resource_uri=APP_URI,
    visibility=["model", "app"],
    meta={"openai/outputTemplate": APP_URI, "openai/widgetAccessible": True},
    description="Show an inline PrivaNet approval card for a scoped temporary administrative lease. This tool does not grant access by itself.",
)
def request_admin_access(
    scope: Literal["privanet.services", "privanet.nodes", "privanet.node_local", "privanet.updates", "system.packages"],
    reason: str,
    context: Context[Any, Any],
) -> dict[str, Any]:
    session_key = _session_key(context)
    status = backend.authorization_status(session_key)
    if any(lease.get("scope") == scope for lease in status.get("leases", [])):
        return {"ok": True, "kind": "authorization", "state": "ALREADY_AUTHORIZED", "scope": scope, "reason": reason, "allows": SCOPES[scope]}
    prepared = backend.prepare_authorization(scope, reason, session_key)
    return {
        "ok": True,
        "kind": "authorization",
        "state": "PENDING_USER_APPROVAL",
        "requestId": prepared["requestId"],
        "scope": scope,
        "reason": reason,
        "allows": SCOPES[scope],
        "followUp": "PrivaNet administrative access was approved. Retry the operation that requested this scope and verify its result.",
    }


@apps.tool(
    resource_uri=APP_URI,
    visibility=["app"],
    meta={"openai/outputTemplate": APP_URI, "openai/widgetAccessible": True},
    description="App-only helper that grants a previously prepared PrivaNet authorization request after the user presses Approve.",
)
def grant_admin_access(request_id: str, duration: Literal["once", "15m", "30m", "60m"], context: Context[Any, Any]) -> dict[str, Any]:
    try:
        return backend.grant_authorization(request_id, duration, _session_key(context))
    except BrokerError as exc:
        return {"ok": False, "code": exc.code, "error": str(exc)}


@apps.tool(
    resource_uri=APP_URI,
    visibility=["app"],
    meta={"openai/outputTemplate": APP_URI, "openai/widgetAccessible": True},
    description="App-only helper that denies and consumes a pending PrivaNet authorization request.",
)
def deny_admin_access(request_id: str, context: Context[Any, Any]) -> dict[str, Any]:
    try:
        return backend.deny_authorization(request_id, _session_key(context))
    except BrokerError as exc:
        return {"ok": False, "code": exc.code, "error": str(exc)}


@apps.tool(
    resource_uri=APP_URI,
    visibility=["model", "app"],
    meta={"openai/outputTemplate": APP_URI, "openai/widgetAccessible": True},
    description="Show an inline one-action confirmation card for a sensitive PrivaNet operation after its normal admin scope is already authorized.",
)
def request_action_confirmation(
    action: Literal["admin.node.revoke", "package.install"],
    target: str,
    reason: str,
    context: Context[Any, Any],
) -> dict[str, Any]:
    try:
        prepared = backend.prepare_confirmation(action, target, reason, _session_key(context))
    except BrokerError as exc:
        return {"ok": False, "code": exc.code, "error": str(exc), "action": action, "target": target}
    return {
        "ok": True,
        "kind": "confirmation",
        "state": "PENDING_USER_CONFIRMATION",
        "requestId": prepared["requestId"],
        "action": action,
        "target": prepared["target"],
        "reason": reason,
        "followUp": "The sensitive PrivaNet action was confirmed. Retry that exact action now and verify the result.",
    }


@apps.tool(
    resource_uri=APP_URI,
    visibility=["app"],
    meta={"openai/outputTemplate": APP_URI, "openai/widgetAccessible": True},
    description="App-only helper that grants a prepared one-action destructive confirmation after the user presses Approve.",
)
def grant_action_confirmation(request_id: str, context: Context[Any, Any]) -> dict[str, Any]:
    try:
        return backend.grant_confirmation(request_id, _session_key(context))
    except BrokerError as exc:
        return {"ok": False, "code": exc.code, "error": str(exc)}


@apps.tool(
    resource_uri=APP_URI,
    visibility=["app"],
    meta={"openai/outputTemplate": APP_URI, "openai/widgetAccessible": True},
    description="App-only helper that denies and consumes a prepared destructive confirmation.",
)
def deny_action_confirmation(request_id: str, context: Context[Any, Any]) -> dict[str, Any]:
    try:
        return backend.deny_confirmation(request_id, _session_key(context))
    except BrokerError as exc:
        return {"ok": False, "code": exc.code, "error": str(exc)}


apps.add_resource(
    TextResource(
        uri=APP_URI,
        name="PrivaNet Admin approval",
        title="PrivaNet Admin approval",
        description="Inline scoped authorization and sensitive-action confirmation card.",
        mime_type="text/html;profile=mcp-app",
        text=APP_HTML,
        meta={
            "ui": {"prefersBorder": True},
            "openai/ui": {"availableDisplayModes": ["inline"], "preferredDisplayMode": "inline"},
        },
    )
)

mcp = MCPServer(
    "PrivaNet Admin",
    version=VERSION,
    extensions=[apps],
    instructions=(
        "Conversational administration for PrivaNet. Read-only diagnostics are available without elevation. "
        "run_command always executes as the locked-down privanet-shell Unix account with a sanitized environment. "
        "Never imply a command or privileged action succeeded unless the returned result says ok=true. "
        "If a privileged tool returns AUTHORIZATION_REQUIRED, call request_admin_access with the returned scope and reason, wait for the user to approve the inline card, then retry. "
        "If a tool returns DESTRUCTIVE_CONFIRMATION_REQUIRED, call request_action_confirmation with the exact returned action, target, and reason, wait for confirmation, then retry. "
        "Privileges are scoped and short-lived; no arbitrary root shell is exposed."
    ),
)

@mcp.tool()
def get_privanet_summary() -> dict[str, Any]:
    """One-call operator summary: services, nodes, PrivaSearch, updates, host capacity, and warnings."""
    return backend.privanet_summary()


@mcp.tool()
def get_services() -> list[dict[str, Any]]:
    """List health/status for every allowlisted Priva service."""
    return backend.list_services()


@mcp.tool()
def get_service_status(service: str) -> dict[str, Any]:
    """Get detailed systemd status for one allowlisted Priva service."""
    return backend.service_status(service)


@mcp.tool()
def get_recent_logs(service: str, lines: int = 100, priority: str | None = None) -> dict[str, Any]:
    """Read a bounded, redacted slice of logs from one allowlisted service through the root broker."""
    return backend.recent_logs(service, lines, priority)


@mcp.tool()
def get_system_health() -> dict[str, Any]:
    """Show homeserver uptime, load, memory and disk capacity."""
    return backend.system_health()


@mcp.tool()
def get_command_environment() -> dict[str, Any]:
    """Describe the locked-down Unix account and restrictions used by run_command."""
    return backend.command_environment()


@mcp.tool()
def run_command(command: str, timeout_seconds: int = 20) -> dict[str, Any]:
    """Run a non-interactive shell command as the unprivileged privanet-shell account. This never becomes root."""
    return backend.run_command(command, timeout_seconds)


@mcp.tool()
def get_nodes(include_revoked: bool = True) -> dict[str, Any]:
    """List enrolled nodes. Set include_revoked=false to hide revoked nodes."""
    return backend.list_nodes(include_revoked)


@mcp.tool()
def get_node(node_reference: str) -> dict[str, Any]:
    """Show detailed coordinator telemetry for one node by ID, unique prefix, or exact name."""
    return backend.get_node(node_reference)


@mcp.tool()
def diagnose_node(node_reference: str) -> dict[str, Any]:
    """Explain visible health problems for one node using coordinator telemetry."""
    return backend.diagnose_node(node_reference)


@mcp.tool()
def get_node_version_drift() -> dict[str, Any]:
    """Group active nodes by daemon version and report whether versions differ."""
    return backend.version_drift()


@mcp.tool()
def get_pending_nodes(include_all: bool = False) -> dict[str, Any]:
    """List pending join requests; include_all also returns historical requests."""
    return backend.list_pending_nodes(include_all)


@mcp.tool()
def get_audit_log(limit: int = 50) -> list[dict[str, Any]]:
    """Return recent shell, bridge, authorization, and privileged-broker audit records."""
    return backend.audit_recent(limit)


@mcp.tool()
def get_authorization_status(context: Context[Any, Any]) -> dict[str, Any]:
    """Show active scoped authorization leases for this MCP session."""
    return backend.authorization_status(_session_key(context))


@mcp.tool()
def revoke_admin_access(context: Context[Any, Any]) -> dict[str, Any]:
    """Immediately revoke all temporary administrative authorization for this MCP session."""
    return backend.revoke_authorization(_session_key(context))



@mcp.tool()
def get_local_node_slots() -> dict[str, Any]:
    """Show the saved/default job-slot setting for the local node when readable without elevation."""
    return backend.local_node_slots()


@mcp.tool()
def get_privasearch_health() -> dict[str, Any]:
    """Read PrivaSearch /health."""
    return backend.privasearch_health()


@mcp.tool()
def get_privasearch_status() -> dict[str, Any]:
    """Read authenticated PrivaSearch operator /status through the root broker without exposing its token."""
    return backend.privasearch_status()


@mcp.tool()
def get_privasearch_summary() -> dict[str, Any]:
    """Return a concise crawler/index summary: queue, throughput, quality, concentration and warnings."""
    return backend.privasearch_summary()


@mcp.tool()
def get_update_status() -> dict[str, Any]:
    """Run a fresh verified update check and return the latest per-app events only."""
    return backend.check_updates()


@mcp.tool()
def get_update_history(limit: int = 100) -> dict[str, Any]:
    """Read bounded historical logs from the Priva application updater."""
    return backend.update_history(limit)


@mcp.tool()
def get_update_schedule() -> dict[str, Any]:
    """Show the systemd schedule/state for the automatic Priva updater."""
    return backend.updater_schedule()


@mcp.tool()
async def restart_service(service: str, context: Context[Any, Any]) -> dict[str, Any]:
    """Restart one allowlisted Priva service after scoped interactive approval if needed."""
    ok, auth = _ensure_scope(context, "privanet.services", f"Restart {service}")
    if not ok:
        return auth
    try:
        result = backend.restart_service(service, _session_key(context))
    except BrokerError as exc:
        return {"ok": False, "code": exc.code, "error": str(exc)}
    result["authorization"] = auth
    return result


@mcp.tool()
async def apply_available_updates(context: Context[Any, Any]) -> dict[str, Any]:
    """Install verified Priva updates after scoped interactive approval if needed."""
    ok, auth = _ensure_scope(context, "privanet.updates", "Install verified Priva application updates; services may restart")
    if not ok:
        return auth
    result = backend.apply_updates(_session_key(context))
    result["authorization"] = auth
    return result


@mcp.tool()
async def approve_node(request_code: str, capabilities: list[str], context: Context[Any, Any], label: str | None = None) -> dict[str, Any]:
    """Approve a pending node with explicit capabilities after scoped approval if needed."""
    ok, auth = _ensure_scope(context, "privanet.nodes", f"Approve pending node request {request_code}")
    if not ok:
        return auth
    result = backend.approve_node(request_code, capabilities, label, _session_key(context))
    result["authorization"] = auth
    return result


@mcp.tool()
async def deny_node(request_code: str, context: Context[Any, Any]) -> dict[str, Any]:
    """Deny a pending node request after scoped approval if needed."""
    ok, auth = _ensure_scope(context, "privanet.nodes", f"Deny pending node request {request_code}")
    if not ok:
        return auth
    result = backend.deny_node(request_code, _session_key(context))
    result["authorization"] = auth
    return result


@mcp.tool()
async def rename_node(node_reference: str, context: Context[Any, Any], name: str | None = None, clear: bool = False) -> dict[str, Any]:
    """Rename an enrolled node, or clear its display name, after scoped approval if needed."""
    ok, auth = _ensure_scope(context, "privanet.nodes", f"Rename node {node_reference}")
    if not ok:
        return auth
    result = backend.rename_node(node_reference, name, clear, _session_key(context))
    result["authorization"] = auth
    return result


@mcp.tool()
async def revoke_node(node_reference: str, context: Context[Any, Any]) -> dict[str, Any]:
    """Revoke a node after node-admin authorization and a separate one-action confirmation."""
    reason = f"Revoke enrolled node {node_reference}"
    ok, auth = _ensure_scope(context, "privanet.nodes", reason)
    if not ok:
        return auth
    shown = backend.get_node(node_reference)
    node = shown.get("node") if shown.get("ok") else None
    if not isinstance(node, dict) or not node.get("nodeId"):
        return {"ok": False, "code": "NODE_UNAVAILABLE", "node_reference": node_reference, "error": shown.get("error") or "Node could not be resolved"}
    node_id = str(node["nodeId"])
    try:
        result = backend.revoke_node(node_id, _session_key(context))
    except BrokerError as exc:
        if exc.code == "CONFIRMATION_REQUIRED":
            return {"ok": False, "code": "DESTRUCTIVE_CONFIRMATION_REQUIRED", "action": "admin.node.revoke", "target": node_id, "reason": f"Revoke node {node.get('displayName') or node_id}. This invalidates its credentials and hands back leased jobs.", "nextTool": "request_action_confirmation"}
        return {"ok": False, "code": exc.code, "error": str(exc)}
    result["authorization"] = auth
    return result


@mcp.tool()
async def set_local_node_slots(slots: int, context: Context[Any, Any]) -> dict[str, Any]:
    """Save a local job-slot override after scoped approval if needed."""
    ok, auth = _ensure_scope(context, "privanet.node_local", f"Set local node job slots to {slots}")
    if not ok:
        return auth
    result = backend.set_local_node_slots(slots, _session_key(context))
    result["authorization"] = auth
    return result


@mcp.tool()
async def clear_local_node_slots(context: Context[Any, Any]) -> dict[str, Any]:
    """Clear the local job-slot override after scoped approval if needed."""
    ok, auth = _ensure_scope(context, "privanet.node_local", "Clear the local node job-slot override")
    if not ok:
        return auth
    result = backend.clear_local_node_slots(_session_key(context))
    result["authorization"] = auth
    return result


@mcp.tool()
async def install_system_package(package: str, context: Context[Any, Any]) -> dict[str, Any]:
    """Install one validated Debian package after package scope and a separate one-action confirmation."""
    package = package.strip().lower()
    reason = f"Install Debian package {package}"
    ok, auth = _ensure_scope(context, "system.packages", reason)
    if not ok:
        return auth
    try:
        result = backend.install_package(package, _session_key(context))
    except BrokerError as exc:
        if exc.code == "CONFIRMATION_REQUIRED":
            return {"ok": False, "code": "DESTRUCTIVE_CONFIRMATION_REQUIRED", "action": "package.install", "target": package, "reason": f"Install system package '{package}' as root using apt-get. Package maintainer scripts run with root privileges.", "nextTool": "request_action_confirmation"}
        return {"ok": False, "code": exc.code, "error": str(exc)}
    result["authorization"] = auth
    return result


app = mcp.streamable_http_app()
