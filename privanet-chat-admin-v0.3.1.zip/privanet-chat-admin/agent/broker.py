from __future__ import annotations

import json
import os
import re
import secrets
import shlex
import socket
import sqlite3
import subprocess
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any

SOCKET_PATH = os.environ.get("PRIVANET_CHAT_ADMIN_BROKER_SOCKET", "/run/privanet-chat-admin/broker.sock")
CONFIG_PATH = os.environ.get("PRIVANET_CHAT_ADMIN_CONFIG", "/etc/privanet-chat-admin/config.json")
STATE_DB = os.environ.get("PRIVANET_CHAT_ADMIN_BROKER_DB", "/var/lib/privanet-chat-admin/broker.sqlite3")
MAX_REQUEST = 128 * 1024

CONFIRMABLE_ACTIONS = {"admin.node.revoke", "package.install"}

SCOPES = {
    "privanet.services",
    "privanet.nodes",
    "privanet.node_local",
    "privanet.updates",
    "system.packages",
}

REQUIRED_SCOPE = {
    "service.restart": "privanet.services",
    "admin.node.approve": "privanet.nodes",
    "admin.node.deny": "privanet.nodes",
    "admin.node.rename": "privanet.nodes",
    "admin.node.revoke": "privanet.nodes",
    "node.slots.set": "privanet.node_local",
    "node.slots.clear": "privanet.node_local",
    "update.apply": "privanet.updates",
    "package.install": "system.packages",
}


class AuthorizationRequired(PermissionError):
    def __init__(self, scope: str):
        super().__init__(f"authorization required: {scope}")
        self.scope = scope


class ConfirmationRequired(PermissionError):
    def __init__(self, action: str, target: str):
        super().__init__(f"confirmation required: {action} {target}")
        self.action = action
        self.target = target


def _config() -> dict[str, Any]:
    with open(CONFIG_PATH, "r", encoding="utf-8") as fh:
        return json.load(fh)


def _db() -> sqlite3.Connection:
    Path(STATE_DB).parent.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(STATE_DB)
    db.execute(
        """
        CREATE TABLE IF NOT EXISTS auth_requests(
          id TEXT PRIMARY KEY,
          created_at INTEGER NOT NULL,
          session_key TEXT NOT NULL,
          scope TEXT NOT NULL,
          reason TEXT NOT NULL,
          consumed INTEGER NOT NULL DEFAULT 0
        )
        """
    )
    db.execute(
        """
        CREATE TABLE IF NOT EXISTS leases(
          id TEXT PRIMARY KEY,
          created_at INTEGER NOT NULL,
          expires_at INTEGER NOT NULL,
          session_key TEXT NOT NULL,
          scope TEXT NOT NULL,
          reason TEXT NOT NULL,
          uses_remaining INTEGER
        )
        """
    )
    db.execute(
        """
        CREATE TABLE IF NOT EXISTS confirmation_requests(
          id TEXT PRIMARY KEY,
          created_at INTEGER NOT NULL,
          session_key TEXT NOT NULL,
          action TEXT NOT NULL,
          target TEXT NOT NULL,
          reason TEXT NOT NULL,
          consumed INTEGER NOT NULL DEFAULT 0
        )
        """
    )
    db.execute(
        """
        CREATE TABLE IF NOT EXISTS confirmations(
          id TEXT PRIMARY KEY,
          created_at INTEGER NOT NULL,
          expires_at INTEGER NOT NULL,
          session_key TEXT NOT NULL,
          action TEXT NOT NULL,
          target TEXT NOT NULL,
          uses_remaining INTEGER NOT NULL
        )
        """
    )
    db.execute(
        """
        CREATE TABLE IF NOT EXISTS audit(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          ts INTEGER NOT NULL,
          action TEXT NOT NULL,
          scope TEXT,
          session_key TEXT,
          ok INTEGER NOT NULL,
          detail TEXT NOT NULL
        )
        """
    )
    db.commit()
    return db


def _audit(action: str, scope: str | None, session_key: str | None, ok: bool, detail: str) -> None:
    with _db() as db:
        db.execute(
            "INSERT INTO audit(ts,action,scope,session_key,ok,detail) VALUES(?,?,?,?,?,?)",
            (int(time.time()), action, scope, session_key, int(ok), detail[:4000]),
        )


def _clean_session(value: Any) -> str:
    text = str(value or "").strip()
    if not re.fullmatch(r"[A-Za-z0-9_.:-]{8,160}", text):
        raise ValueError("invalid session key")
    return text


def _active_lease(scope: str, session_key: str, consume: bool) -> dict[str, Any] | None:
    now = int(time.time())
    with _db() as db:
        db.execute("DELETE FROM leases WHERE expires_at <= ? OR uses_remaining = 0", (now,))
        row = db.execute(
            "SELECT id,created_at,expires_at,scope,reason,uses_remaining FROM leases "
            "WHERE session_key=? AND scope=? AND expires_at>? AND (uses_remaining IS NULL OR uses_remaining>0) "
            "ORDER BY expires_at DESC LIMIT 1",
            (session_key, scope, now),
        ).fetchone()
        if row is None:
            return None
        if consume and row[5] is not None:
            db.execute("UPDATE leases SET uses_remaining=uses_remaining-1 WHERE id=?", (row[0],))
        db.commit()
    return {
        "id": row[0],
        "createdAt": row[1],
        "expiresAt": row[2],
        "scope": row[3],
        "reason": row[4],
        "usesRemaining": None if row[5] is None else max(0, row[5] - (1 if consume else 0)),
    }


def _require_scope(action: str, session_key: str, *, consume: bool = True) -> dict[str, Any] | None:
    scope = REQUIRED_SCOPE.get(action)
    if scope is None:
        return None
    lease = _active_lease(scope, session_key, consume=consume)
    if lease is None:
        raise AuthorizationRequired(scope)
    return lease


def _active_confirmation(action: str, target: str, session_key: str, consume: bool) -> dict[str, Any] | None:
    now = int(time.time())
    with _db() as db:
        db.execute("DELETE FROM confirmations WHERE expires_at <= ? OR uses_remaining <= 0", (now,))
        row = db.execute(
            "SELECT id,created_at,expires_at,action,target,uses_remaining FROM confirmations "
            "WHERE session_key=? AND action=? AND target=? AND expires_at>? AND uses_remaining>0 "
            "ORDER BY expires_at DESC LIMIT 1",
            (session_key, action, target, now),
        ).fetchone()
        if row is None:
            return None
        if consume:
            db.execute("UPDATE confirmations SET uses_remaining=uses_remaining-1 WHERE id=?", (row[0],))
        db.commit()
    return {
        "id": row[0], "createdAt": row[1], "expiresAt": row[2], "action": row[3],
        "target": row[4], "usesRemaining": max(0, row[5] - (1 if consume else 0)),
    }


def _require_confirmation(action: str, target: str, session_key: str, *, consume: bool = True) -> dict[str, Any]:
    confirmation = _active_confirmation(action, target, session_key, consume=consume)
    if confirmation is None:
        raise ConfirmationRequired(action, target)
    return confirmation


def _run(argv: list[str], timeout: int = 60, env: dict[str, str] | None = None) -> dict[str, Any]:
    proc = subprocess.run(
        argv,
        text=True,
        capture_output=True,
        timeout=timeout,
        check=False,
        env=env or {"PATH": "/opt/node/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin", "LANG": "C.UTF-8"},
    )
    return {
        "ok": proc.returncode == 0,
        "code": proc.returncode,
        "stdout": proc.stdout[-40000:],
        "stderr": proc.stderr[-20000:],
    }




def _run_unit(unit: str, start_timeout: int) -> dict[str, Any]:
    if not re.fullmatch(r"[A-Za-z0-9_.@-]+\.service", unit):
        raise ValueError("invalid unit")
    started_at = int(time.time()) - 1
    started = _run(["systemctl", "start", unit], timeout=start_timeout)
    props = _run(["systemctl", "show", unit, "--no-page", "--property=Result,ExecMainStatus,ActiveState,SubState"], timeout=30)
    values = {}
    for line in props["stdout"].splitlines():
        if "=" in line:
            k,v=line.split("=",1); values[k]=v
    logs = _run(["journalctl", "-u", unit, "--since", f"@{started_at}", "--no-pager", "--output=cat", "-n", "500"], timeout=30)
    ok = started["ok"] and values.get("Result") in {"", "success"} and values.get("ExecMainStatus") in {"", "0"}
    return {"ok": ok, "state": values, "output": logs["stdout"], "error": started["stderr"] or props["stderr"] or logs["stderr"] or None}

def _json_output(result: dict[str, Any]) -> Any:
    if not result["ok"]:
        return None
    try:
        return json.loads(result["stdout"])
    except json.JSONDecodeError:
        return result["stdout"]


def _admin(args: list[str], timeout: int = 60) -> dict[str, Any]:
    cfg = _config()
    binary = cfg.get("executables", {}).get("privanet_admin", "/usr/local/bin/privanet-admin")
    return _run([binary, *args], timeout=timeout)


def _service_alias(name: str) -> str:
    cfg = _config()
    services = cfg.get("managed_services", {})
    if name not in services:
        raise ValueError("unknown managed service")
    return str(services[name])


def _node_ref(value: Any) -> str:
    text = str(value or "").strip()
    if not text or len(text) > 160 or text.startswith("-") or not re.fullmatch(r"[A-Za-z0-9_.:@+\- ]+", text):
        raise ValueError("invalid node reference")
    return text


def _request_code(value: Any) -> str:
    text = str(value or "").strip().upper().replace(" ", "-")
    if not re.fullmatch(r"[A-Z0-9]{4}-?[A-Z0-9]{4}", text):
        raise ValueError("invalid request code")
    return text if "-" in text else f"{text[:4]}-{text[4:]}"


def _label(value: Any) -> str:
    text = str(value or "").strip()
    if not text or len(text) > 80 or any(ord(ch) < 32 for ch in text):
        raise ValueError("invalid label")
    return text


def _caps(value: Any) -> list[str]:
    if not isinstance(value, list) or not value:
        raise ValueError("capabilities required")
    out: list[str] = []
    for item in value:
        text = str(item).strip()
        if not re.fullmatch(r"[a-z0-9][a-z0-9._-]{0,95}", text):
            raise ValueError("invalid capability")
        if text not in out:
            out.append(text)
    return out


def _search_status() -> dict[str, Any]:
    cfg = _config()
    search = cfg.get("privasearch", {})
    base = str(search.get("base_url", "http://127.0.0.1:4020")).rstrip("/")
    parsed = urllib.parse.urlsplit(base)
    if parsed.scheme != "http" or parsed.hostname not in {"127.0.0.1", "localhost", "::1"}:
        raise ValueError("PrivaSearch URL must be loopback HTTP")
    token = None
    env_path = Path(str(search.get("env_file", "/etc/privasearch/privasearch.env")))
    try:
        for raw in env_path.read_text(encoding="utf-8").splitlines():
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("export "):
                line = line[7:].lstrip()
            if "=" not in line:
                continue
            key, val = line.split("=", 1)
            if key.strip() == "PRIVASEARCH_API_TOKEN":
                try:
                    parsed_val = shlex.split(val.strip(), posix=True)
                    token = parsed_val[0] if len(parsed_val) == 1 else val.strip().strip("'\"")
                except ValueError:
                    token = val.strip().strip("'\"")
                break
    except OSError:
        pass
    headers = {"Accept": "application/json", "User-Agent": "PrivaNet-Chat-Admin-Broker/0.3.1"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    req = urllib.request.Request(base + "/status", headers=headers, method="GET")
    opener = urllib.request.build_opener(urllib.request.HTTPHandler())
    try:
        with opener.open(req, timeout=5) as response:
            raw = response.read(2 * 1024 * 1024 + 1)
            if len(raw) > 2 * 1024 * 1024:
                raise ValueError("PrivaSearch response too large")
            return {"ok": 200 <= response.status < 300, "http_status": response.status, "data": json.loads(raw.decode("utf-8")), "error": None}
    except (urllib.error.URLError, OSError, ValueError, json.JSONDecodeError) as exc:
        return {"ok": False, "http_status": None, "data": None, "error": str(exc)[:1000]}


def handle(request: dict[str, Any]) -> dict[str, Any]:
    action = str(request.get("action", ""))
    params = request.get("params") or {}
    if not isinstance(params, dict):
        raise ValueError("params must be an object")
    session_key = _clean_session(request.get("session_key", "session-unknown"))

    if action == "auth.prepare":
        scope = str(params.get("scope", ""))
        reason = str(params.get("reason", "")).strip()[:500]
        if scope not in SCOPES or not reason:
            raise ValueError("invalid authorization request")
        req_id = "req_" + secrets.token_hex(16)
        with _db() as db:
            db.execute(
                "INSERT INTO auth_requests(id,created_at,session_key,scope,reason,consumed) VALUES(?,?,?,?,?,0)",
                (req_id, int(time.time()), session_key, scope, reason),
            )
            db.commit()
        _audit("auth.prepare", scope, session_key, True, reason)
        return {"ok": True, "requestId": req_id, "scope": scope, "reason": reason}

    if action == "auth.grant":
        req_id = str(params.get("request_id", ""))
        duration = str(params.get("duration", ""))
        durations = {"once": (300, 1), "15m": (900, None), "30m": (1800, None), "60m": (3600, None)}
        if duration not in durations:
            raise ValueError("invalid duration")
        now = int(time.time())
        with _db() as db:
            row = db.execute(
                "SELECT session_key,scope,reason,created_at,consumed FROM auth_requests WHERE id=?",
                (req_id,),
            ).fetchone()
            if row is None or row[0] != session_key or row[4] or now - row[3] > 300:
                raise PermissionError("authorization request expired or invalid")
            seconds, uses = durations[duration]
            lease_id = "lease_" + secrets.token_hex(16)
            db.execute("UPDATE auth_requests SET consumed=1 WHERE id=?", (req_id,))
            db.execute(
                "INSERT INTO leases(id,created_at,expires_at,session_key,scope,reason,uses_remaining) VALUES(?,?,?,?,?,?,?)",
                (lease_id, now, now + seconds, session_key, row[1], row[2], uses),
            )
            db.commit()
        _audit("auth.grant", row[1], session_key, True, f"duration={duration}; {row[2]}")
        return {"ok": True, "scope": row[1], "expiresAt": now + seconds, "duration": duration, "usesRemaining": uses}

    if action == "auth.deny":
        req_id = str(params.get("request_id", ""))
        now = int(time.time())
        with _db() as db:
            row = db.execute(
                "SELECT scope,reason,created_at,consumed FROM auth_requests WHERE id=? AND session_key=?",
                (req_id, session_key),
            ).fetchone()
            if row is None or row[3] or now - row[2] > 300:
                raise PermissionError("authorization request expired or invalid")
            db.execute("UPDATE auth_requests SET consumed=1 WHERE id=?", (req_id,))
            db.commit()
        _audit("auth.deny", row[0], session_key, True, row[1])
        return {"ok": True, "denied": True, "scope": row[0]}

    if action == "confirm.prepare":
        confirm_action = str(params.get("action", ""))
        target = str(params.get("target", "")).strip()
        reason = str(params.get("reason", "")).strip()[:500]
        if confirm_action not in CONFIRMABLE_ACTIONS or not target or len(target) > 200 or not reason:
            raise ValueError("invalid confirmation request")
        if confirm_action == "package.install":
            target = target.lower()
            if not re.fullmatch(r"[a-z0-9][a-z0-9+.-]{0,127}", target):
                raise ValueError("invalid package confirmation target")
        else:
            target = _node_ref(target)
        required_scope = REQUIRED_SCOPE[confirm_action]
        if _active_lease(required_scope, session_key, consume=False) is None:
            raise AuthorizationRequired(required_scope)
        req_id = "confirm_req_" + secrets.token_hex(16)
        with _db() as db:
            db.execute(
                "INSERT INTO confirmation_requests(id,created_at,session_key,action,target,reason,consumed) VALUES(?,?,?,?,?,?,0)",
                (req_id, int(time.time()), session_key, confirm_action, target, reason),
            )
            db.commit()
        _audit("confirm.prepare", REQUIRED_SCOPE.get(confirm_action), session_key, True, f"{confirm_action} {target}: {reason}")
        return {"ok": True, "requestId": req_id, "action": confirm_action, "target": target, "reason": reason}

    if action == "confirm.grant":
        req_id = str(params.get("request_id", ""))
        now = int(time.time())
        with _db() as db:
            row = db.execute(
                "SELECT session_key,action,target,reason,created_at,consumed FROM confirmation_requests WHERE id=?",
                (req_id,),
            ).fetchone()
            if row is None or row[0] != session_key or row[5] or now - row[4] > 300:
                raise PermissionError("confirmation request expired or invalid")
            confirmation_id = "confirm_" + secrets.token_hex(16)
            db.execute("UPDATE confirmation_requests SET consumed=1 WHERE id=?", (req_id,))
            db.execute(
                "INSERT INTO confirmations(id,created_at,expires_at,session_key,action,target,uses_remaining) VALUES(?,?,?,?,?,?,1)",
                (confirmation_id, now, now + 300, session_key, row[1], row[2]),
            )
            db.commit()
        _audit("confirm.grant", REQUIRED_SCOPE.get(row[1]), session_key, True, f"{row[1]} {row[2]}")
        return {"ok": True, "action": row[1], "target": row[2], "expiresAt": now + 300, "usesRemaining": 1}

    if action == "confirm.deny":
        req_id = str(params.get("request_id", ""))
        now = int(time.time())
        with _db() as db:
            row = db.execute(
                "SELECT action,target,reason,created_at,consumed FROM confirmation_requests WHERE id=? AND session_key=?",
                (req_id, session_key),
            ).fetchone()
            if row is None or row[4] or now - row[3] > 300:
                raise PermissionError("confirmation request expired or invalid")
            db.execute("UPDATE confirmation_requests SET consumed=1 WHERE id=?", (req_id,))
            db.commit()
        _audit("confirm.deny", REQUIRED_SCOPE.get(row[0]), session_key, True, f"{row[0]} {row[1]}: {row[2]}")
        return {"ok": True, "denied": True, "action": row[0], "target": row[1]}

    if action == "auth.status":
        now = int(time.time())
        with _db() as db:
            db.execute("DELETE FROM leases WHERE expires_at <= ? OR uses_remaining = 0", (now,))
            rows = db.execute(
                "SELECT created_at,expires_at,scope,reason,uses_remaining FROM leases WHERE session_key=? ORDER BY expires_at DESC",
                (session_key,),
            ).fetchall()
            db.commit()
        return {"ok": True, "leases": [
            {"createdAt": r[0], "expiresAt": r[1], "scope": r[2], "reason": r[3], "usesRemaining": r[4]}
            for r in rows
        ]}

    if action == "auth.revoke_all":
        with _db() as db:
            count = db.execute("DELETE FROM leases WHERE session_key=?", (session_key,)).rowcount
            db.commit()
        _audit("auth.revoke_all", None, session_key, True, f"revoked={count}")
        return {"ok": True, "revoked": count}

    if action == "audit.recent":
        limit = max(1, min(int(params.get("limit", 50)), 200))
        with _db() as db:
            rows = db.execute(
                "SELECT ts,action,scope,session_key,ok,detail FROM audit ORDER BY id DESC LIMIT ?", (limit,)
            ).fetchall()
        return {"ok": True, "entries": [
            {"ts": r[0], "action": r[1], "scope": r[2], "session": r[3], "ok": bool(r[4]), "detail": r[5]}
            for r in rows
        ]}

    # Read-only broker operations. They do not require an elevation lease.
    if action == "service.status":
        unit = _service_alias(str(params.get("service", "")))
        result = _run(["systemctl", "show", unit, "--no-page", "--property=ActiveState,SubState,MainPID,ExecMainStatus,ActiveEnterTimestamp,Result"])
        return {"ok": result["ok"], "unit": unit, "output": result["stdout"], "error": result["stderr"] or None}
    if action == "logs.read":
        unit = _service_alias(str(params.get("service", "")))
        lines = max(1, min(int(params.get("lines", 100)), 300))
        argv = ["journalctl", "-u", unit, "-n", str(lines), "--no-pager", "--output=short-iso"]
        priority = params.get("priority")
        if priority:
            if priority not in {"emerg", "alert", "crit", "err", "warning", "notice", "info", "debug"}:
                raise ValueError("invalid priority")
            argv += ["-p", str(priority)]
        result = _run(argv)
        return {"ok": result["ok"], "logs": result["stdout"], "error": result["stderr"] or None}
    if action == "admin.nodes.list":
        result = _admin(["nodes", "list", "--json"])
        return {"ok": result["ok"], "data": _json_output(result), "error": result["stderr"] or None}
    if action == "admin.nodes.show":
        ref = _node_ref(params.get("node_reference"))
        result = _admin(["nodes", "show", ref, "--json"])
        return {"ok": result["ok"], "data": _json_output(result), "error": result["stderr"] or None}
    if action == "admin.requests.list":
        argv = ["requests", "list"]
        if bool(params.get("include_all")):
            argv.append("--all")
        argv.append("--json")
        result = _admin(argv)
        return {"ok": result["ok"], "data": _json_output(result), "error": result["stderr"] or None}
    if action == "search.status":
        return _search_status()
    if action == "node.slots.show":
        cfg = _config()
        binary = cfg.get("executables", {}).get("privanet_node", "/opt/privanet-node/current/bin/privanet-node")
        state_dir = str(cfg.get("local_node_state_dir", "/var/lib/privanet-node"))
        result = _run([binary, "slots", "show", "--json", "--state-dir", state_dir])
        return {"ok": result["ok"], "data": _json_output(result), "error": result["stderr"] or None}
    if action == "update.schedule":
        result = _run(["systemctl", "show", "privanet-update.timer", "--no-page", "--property=LoadState,ActiveState,SubState,LastTriggerUSec,NextElapseUSecRealtime"])
        return {"ok": result["ok"], "output": result["stdout"], "error": result["stderr"] or None}
    if action == "update.check":
        return _run_unit("privanet-chat-admin-update-check.service", 7200)

    destructive = action in CONFIRMABLE_ACTIONS
    lease = _require_scope(action, session_key, consume=not destructive)
    scope = REQUIRED_SCOPE.get(action)

    if action == "service.restart":
        unit = _service_alias(str(params.get("service", "")))
        result = _run(["systemctl", "restart", unit], timeout=120)
        state = _run(["systemctl", "show", unit, "--no-page", "--property=ActiveState,SubState,MainPID,ExecMainStatus,Result"])
        ok = result["ok"] and "ActiveState=active" in state["stdout"]
        _audit(action, scope, session_key, ok, unit)
        return {"ok": ok, "unit": unit, "state": state["stdout"], "error": result["stderr"] or state["stderr"] or None, "lease": lease}

    if action == "admin.node.approve":
        code = _request_code(params.get("request_code"))
        caps = _caps(params.get("capabilities"))
        argv = ["approve", code, "--capabilities", ",".join(caps)]
        if params.get("label") is not None:
            argv += ["--label", _label(params.get("label"))]
        argv.append("--json")
        result = _admin(argv)
        _audit(action, scope, session_key, result["ok"], code)
        return {"ok": result["ok"], "data": _json_output(result), "error": result["stderr"] or None, "lease": lease}

    if action == "admin.node.deny":
        code = _request_code(params.get("request_code"))
        result = _admin(["deny", code, "--json"])
        _audit(action, scope, session_key, result["ok"], code)
        return {"ok": result["ok"], "data": _json_output(result), "error": result["stderr"] or None, "lease": lease}

    if action == "admin.node.rename":
        ref = _node_ref(params.get("node_reference"))
        if params.get("clear"):
            argv = ["nodes", "rename", ref, "--clear"]
        else:
            argv = ["nodes", "rename", ref, _label(params.get("name"))]
        result = _admin(argv)
        _audit(action, scope, session_key, result["ok"], ref)
        return {"ok": result["ok"], "output": result["stdout"], "error": result["stderr"] or None, "lease": lease}

    if action == "admin.node.revoke":
        ref = _node_ref(params.get("node_reference"))
        shown = _admin(["nodes", "show", ref, "--json"])
        if not shown["ok"]:
            _audit(action, scope, session_key, False, ref)
            return {"ok": False, "output": shown["stdout"], "error": shown["stderr"] or "node could not be resolved", "lease": lease}
        node = _json_output(shown)
        if not isinstance(node, dict) or not node.get("nodeId"):
            raise ValueError("node lookup did not return a nodeId")
        node_id = _node_ref(node["nodeId"])
        confirmation = _require_confirmation(action, node_id, session_key, consume=True)
        lease = _require_scope(action, session_key, consume=True)
        result = _admin(["nodes", "revoke", node_id])
        _audit(action, scope, session_key, result["ok"], node_id)
        return {"ok": result["ok"], "output": result["stdout"], "error": result["stderr"] or None, "lease": lease, "confirmation": confirmation}

    if action in {"node.slots.set", "node.slots.clear"}:
        cfg = _config()
        binary = cfg.get("executables", {}).get("privanet_node", "/opt/privanet-node/current/bin/privanet-node")
        state_dir = str(cfg.get("local_node_state_dir", "/var/lib/privanet-node"))
        if action == "node.slots.set":
            maximum = int(cfg.get("limits", {}).get("max_job_slots", 32))
            slots = int(params.get("slots"))
            if slots < 1 or slots > maximum:
                raise ValueError("invalid slots")
            argv = [binary, "slots", "set", str(slots), "--json", "--state-dir", state_dir]
        else:
            argv = [binary, "slots", "clear", "--json", "--state-dir", state_dir]
        result = _run(argv)
        _audit(action, scope, session_key, result["ok"], result["stderr"] or result["stdout"])
        return {"ok": result["ok"], "data": _json_output(result), "error": result["stderr"] or None, "lease": lease}

    if action == "update.apply":
        result = _run_unit("privanet-update.service", 7200)
        _audit(action, scope, session_key, result["ok"], result.get("output", "")[-3000:] or str(result.get("error") or ""))
        result["lease"] = lease
        return result

    if action == "package.install":
        package = str(params.get("package", "")).strip().lower()
        if not re.fullmatch(r"[a-z0-9][a-z0-9+.-]{0,127}", package):
            raise ValueError("invalid package name")
        confirmation = _require_confirmation(action, package, session_key, consume=True)
        lease = _require_scope(action, session_key, consume=True)
        unit = "privanet-chat-admin-pkg-" + secrets.token_hex(6) + ".service"
        result = _run([
            "/usr/bin/systemd-run", "--quiet", "--wait", "--pipe", "--collect",
            "--unit", unit, "/usr/bin/apt-get", "install", "-y", "--no-install-recommends", package
        ], timeout=1800)
        _audit(action, scope, session_key, result["ok"], package)
        return {"ok": result["ok"], "package": package, "output": result["stdout"][-12000:], "error": result["stderr"][-6000:] or None, "lease": lease, "confirmation": confirmation}

    raise ValueError("unsupported broker action")


def _serve_connection(conn: socket.socket) -> None:
    data = b""
    while b"\n" not in data and len(data) <= MAX_REQUEST:
        chunk = conn.recv(65536)
        if not chunk:
            break
        data += chunk
    try:
        if len(data) > MAX_REQUEST:
            raise ValueError("request too large")
        request = json.loads(data.split(b"\n", 1)[0].decode("utf-8"))
        if not isinstance(request, dict):
            raise ValueError("request must be an object")
        result = handle(request)
        response = {"ok": True, "result": result}
    except ConfirmationRequired as exc:
        response = {"ok": False, "error": {"code": "CONFIRMATION_REQUIRED", "message": str(exc), "action": exc.action, "target": exc.target}}
    except AuthorizationRequired as exc:
        response = {"ok": False, "error": {"code": "AUTHORIZATION_REQUIRED", "message": str(exc), "scope": exc.scope}}
    except PermissionError as exc:
        response = {"ok": False, "error": {"code": "AUTHORIZATION_REQUEST_INVALID", "message": str(exc)}}
    except Exception as exc:
        response = {"ok": False, "error": {"code": "BROKER_REQUEST_FAILED", "message": str(exc)[:500]}}
    conn.sendall((json.dumps(response, separators=(",", ":")) + "\n").encode("utf-8"))


def main() -> None:
    path = Path(SOCKET_PATH)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() or path.is_socket():
        path.unlink()
    with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as server:
        server.bind(str(path))
        os.chmod(path, 0o660)
        server.listen(32)
        while True:
            conn, _ = server.accept()
            with conn:
                _serve_connection(conn)


if __name__ == "__main__":
    main()
