#!/usr/bin/env python3
"""Root-only fallback authorization/confirmation utility for clients without MCP App approval UI."""
from __future__ import annotations

import argparse
import json
import os
import socket
import sys

SOCKET = "/run/privanet-chat-admin/broker.sock"
SCOPES = ["privanet.services", "privanet.nodes", "privanet.node_local", "privanet.updates", "system.packages"]
CONFIRM_ACTIONS = ["admin.node.revoke", "package.install"]


def call(action: str, params: dict[str, object], session_key: str) -> dict[str, object]:
    payload = json.dumps({"action": action, "params": params, "session_key": session_key}) + "\n"
    with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as s:
        s.connect(SOCKET)
        s.sendall(payload.encode())
        data = b""
        while b"\n" not in data:
            chunk = s.recv(65536)
            if not chunk:
                break
            data += chunk
    return json.loads(data.split(b"\n", 1)[0])


def main() -> int:
    if os.geteuid() != 0:
        print("Run as root.", file=sys.stderr)
        return 1
    p = argparse.ArgumentParser()
    p.add_argument("scope", nargs="?", choices=SCOPES, help="Scoped admin lease to grant")
    p.add_argument("--session", required=True, help="MCP session key shown by get_authorization_status")
    p.add_argument("--duration", choices=["once", "15m", "30m", "60m"], default="once")
    p.add_argument("--reason", default="Local operator approval")
    p.add_argument("--confirm-action", choices=CONFIRM_ACTIONS, help="Grant one destructive confirmation instead of an admin lease")
    p.add_argument("--target", help="Exact target for --confirm-action")
    args = p.parse_args()

    if args.confirm_action:
        if args.scope:
            p.error("do not provide a scope with --confirm-action")
        if not args.target:
            p.error("--target is required with --confirm-action")
        prep = call("confirm.prepare", {"action": args.confirm_action, "target": args.target, "reason": args.reason}, args.session)
        if not prep.get("ok"):
            print(json.dumps(prep, indent=2))
            return 1
        request_id = prep["result"]["requestId"]
        grant = call("confirm.grant", {"request_id": request_id}, args.session)
    else:
        if not args.scope:
            p.error("scope is required unless --confirm-action is used")
        prep = call("auth.prepare", {"scope": args.scope, "reason": args.reason}, args.session)
        if not prep.get("ok"):
            print(json.dumps(prep, indent=2))
            return 1
        request_id = prep["result"]["requestId"]
        grant = call("auth.grant", {"request_id": request_id, "duration": args.duration}, args.session)

    print(json.dumps(grant, indent=2))
    return 0 if grant.get("ok") else 1


if __name__ == "__main__":
    raise SystemExit(main())
