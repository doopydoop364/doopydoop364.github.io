import json
from pathlib import Path

import pytest

from agent.core import AdminBackend, BrokerError, Runner, redact


class FakeBroker:
    def __init__(self):
        self.calls=[]
        self.responses={}
    def set(self, action, response): self.responses[action]=response
    def call(self, action, params=None, session_key='session-default'):
        self.calls.append((action, params or {}, session_key))
        response=self.responses.get(action, {'ok':True})
        if isinstance(response, Exception): raise response
        return response


class FakeShell:
    def __init__(self): self.calls=[]; self.response={'ok':True,'exitCode':0,'durationSeconds':0.01,'stdout':'ok\n','stderr':''}
    def run(self, command, timeout_seconds): self.calls.append((command,timeout_seconds)); return dict(self.response)


class FakeRunner:
    def __init__(self): self.calls=[]
    def run(self, argv, **kwargs): self.calls.append((argv,kwargs)); raise AssertionError('runner should not be used in this test')


def cfg(tmp_path: Path):
    updater=tmp_path/'privanet-update'; updater.write_text('#!/bin/sh\n'); updater.chmod(0o755)
    updater_config=tmp_path/'updater.json'; updater_config.write_text('{"version":1,"channel":"prerelease"}\n')
    return {
        'audit_db':str(tmp_path/'audit.sqlite3'),
        'command_home':str(tmp_path/'home'), 'command_cwd':str(tmp_path/'work'),
        'local_node_state_dir':'/var/lib/privanet-node',
        'command_path':'/opt/node/bin:/usr/bin:/bin',
        'managed_services':{'coordinator':'privanet-coordinator.service','node':'privanet-node.service','search':'privasearch.service','proxy':'privaproxy.service','updater':'privanet-update.service'},
        'executables':{'privanet_admin':'/usr/local/bin/privanet-admin','privanet_node':'/opt/privanet-node/current/bin/privanet-node','privanet_update':str(updater)},
        'broker':{'socket':'/run/privanet-chat-admin/broker.sock','timeout_seconds':1},
        'shell':{'socket':'/run/privanet-chat-shell/shell.sock','timeout_seconds':2},
        'privasearch':{'base_url':'http://127.0.0.1:4020','env_file':'/etc/privasearch/privasearch.env'},
        'updater':{'config_file':str(updater_config)},
        'diagnostic_paths':[str(tmp_path)],
        'limits':{'max_log_lines':50,'max_job_slots':16,'command_timeout_seconds':1,'max_command_timeout_seconds':60,'update_timeout_seconds':2},
    }


def backend(tmp_path, broker=None, shell=None):
    return AdminBackend(cfg(tmp_path), runner=FakeRunner(), broker=broker or FakeBroker(), shell=shell or FakeShell(), http_json=lambda *a,**k:{'ok':True,'http_status':200,'data':{'status':'ok','version':'0.5.1'},'error':None})


def test_runner_default_path_contains_opt_node():
    assert '/opt/node/bin' in Runner().command_path.split(':')


def test_run_command_uses_separate_shell_identity(tmp_path):
    sh=FakeShell(); b=backend(tmp_path,shell=sh)
    out=b.run_command('uname -a',12)
    assert sh.calls==[('uname -a',12)]
    assert out['executedAs']=='privanet-shell'
    assert out['privilege']=='unprivileged'


def test_run_command_bounded_timeout_and_redacts(tmp_path):
    sh=FakeShell(); sh.response={'ok':True,'exitCode':0,'durationSeconds':1,'stdout':'token=abc\n','stderr':''}
    b=backend(tmp_path,shell=sh)
    out=b.run_command('echo hi',999)
    assert sh.calls[0][1]==60
    assert 'abc' not in out['stdout']


def test_service_allowlist_blocks_unmanaged_unit(tmp_path):
    b=backend(tmp_path)
    with pytest.raises(ValueError): b.service_status('sshd')


def test_service_status_uses_broker_read_path(tmp_path):
    br=FakeBroker(); br.set('service.status',{'ok':True,'unit':'privanet-node.service','output':'ActiveState=active\nSubState=running\n','error':None})
    b=backend(tmp_path,broker=br); out=b.service_status('node')
    assert out['state']['ActiveState']=='active'
    assert br.calls[-1][0]=='service.status'


def test_nodes_can_hide_revoked(tmp_path):
    br=FakeBroker(); br.set('admin.nodes.list',{'ok':True,'data':{'nodes':[{'nodeId':'a','status':'ONLINE'},{'nodeId':'b','status':'REVOKED'}]},'error':None})
    b=backend(tmp_path,broker=br)
    assert [n['nodeId'] for n in b.list_nodes(False)['nodes']]==['a']


def test_get_and_diagnose_node(tmp_path):
    br=FakeBroker(); br.set('admin.nodes.show',{'ok':True,'data':{'nodeId':'n','status':'OFFLINE','jobSlots':0,'currentJobs':0,'pressure':'ELEVATED'},'error':None})
    b=backend(tmp_path,broker=br); out=b.diagnose_node('node_12345678')
    codes={x['code'] for x in out['diagnosis']}
    assert {'OFFLINE','NO_SLOTS','RESOURCE_PRESSURE'} <= codes


def test_version_drift(tmp_path):
    br=FakeBroker(); br.set('admin.nodes.list',{'ok':True,'data':{'nodes':[{'status':'ONLINE','daemonVersion':'1.0','displayName':'a'},{'status':'ONLINE','daemonVersion':'1.1','displayName':'b'}]},'error':None})
    assert backend(tmp_path,broker=br).version_drift()['drift'] is True


def test_restart_calls_scoped_broker_action(tmp_path):
    br=FakeBroker(); br.set('service.restart',{'ok':True,'state':'ActiveState=active\n','error':None})
    out=backend(tmp_path,broker=br).restart_service('node','mcp_12345678')
    assert out['ok'] is True
    assert br.calls[-1]==('service.restart',{'service':'node'},'mcp_12345678')


def test_node_mutations_use_broker(tmp_path):
    br=FakeBroker(); b=backend(tmp_path,broker=br)
    b.approve_node('ABCD-EF12',['web.fetch.v1'],'crawler','mcp_12345678')
    assert br.calls[-1][0]=='admin.node.approve'
    b.deny_node('ABCD-EF12','mcp_12345678'); assert br.calls[-1][0]=='admin.node.deny'
    b.rename_node('node_12345678','worker',False,'mcp_12345678'); assert br.calls[-1][0]=='admin.node.rename'
    b.revoke_node('node_12345678','mcp_12345678'); assert br.calls[-1][0]=='admin.node.revoke'


def test_node_reference_rejects_option_injection(tmp_path):
    with pytest.raises(ValueError): backend(tmp_path).get_node('--help')


def test_local_slots_are_bounded_and_brokered(tmp_path):
    br=FakeBroker(); b=backend(tmp_path,broker=br)
    b.set_local_node_slots(8,'mcp_12345678')
    assert br.calls[-1][0]=='node.slots.set'
    with pytest.raises(ValueError): b.set_local_node_slots(17,'mcp_12345678')


def test_local_slots_show_is_read_only_broker_action(tmp_path):
    br=FakeBroker(); br.set('node.slots.show',{'ok':True,'data':{'slots':4},'error':None})
    assert backend(tmp_path,broker=br).local_node_slots()['slots']=={'slots':4}


def test_update_check_returns_fresh_per_app_events(tmp_path):
    br=FakeBroker(); br.set('update.check',{'ok':True,'output':'{"app":"core","code":"UP_TO_DATE","version":"0.4.0-alpha.4"}\n{"app":"proxy","code":"UPDATE_AVAILABLE","target":"v1.2.1"}\n','error':None})
    out=backend(tmp_path,broker=br).check_updates()
    assert len(out['apps'])==2 and out['apps'][1]['code']=='UPDATE_AVAILABLE'


def test_update_check_reports_missing_prerequisites(tmp_path):
    c=cfg(tmp_path); Path(c['executables']['privanet_update']).unlink()
    b=AdminBackend(c,runner=FakeRunner(),broker=FakeBroker(),shell=FakeShell())
    assert b.check_updates()['events'][0]['code']=='UPDATER_NOT_INSTALLED'


def test_privasearch_status_secret_stays_in_broker(tmp_path):
    br=FakeBroker(); br.set('search.status',{'ok':True,'http_status':200,'data':{'frontier':{'PENDING':12}},'error':None})
    out=backend(tmp_path,broker=br).privasearch_status()
    assert out['data']['frontier']['PENDING']==12
    assert br.calls[-1][0]=='search.status'


def test_privasearch_summary(tmp_path):
    br=FakeBroker(); br.set('search.status',{'ok':True,'http_status':200,'data':{'frontier':{'PENDING':12},'quality':{'duplicates':2},'throughput':{'perMinute':5},'warnings':[]},'error':None})
    out=backend(tmp_path,broker=br).privasearch_summary()
    assert out['queue']['PENDING']==12 and out['quality']['duplicates']==2


def test_authorization_round_trip_backend(tmp_path):
    br=FakeBroker(); br.set('auth.prepare',{'ok':True,'requestId':'req_x','scope':'privanet.services'}); br.set('auth.grant',{'ok':True,'scope':'privanet.services','expiresAt':123}); br.set('auth.status',{'ok':True,'leases':[]})
    b=backend(tmp_path,broker=br)
    p=b.prepare_authorization('privanet.services','restart node','mcp_12345678')
    g=b.grant_authorization(p['requestId'],'once','mcp_12345678')
    s=b.authorization_status('mcp_12345678')
    assert g['scope']=='privanet.services' and s['mcpSessionKey']=='mcp_12345678'


def test_unknown_authorization_scope_rejected(tmp_path):
    with pytest.raises(ValueError): backend(tmp_path).prepare_authorization('root.shell','x','mcp_12345678')


def test_install_package_validates_name_and_brokers(tmp_path):
    br=FakeBroker(); br.set('package.install',{'ok':True,'package':'jq','output':'done','error':None})
    b=backend(tmp_path,broker=br); assert b.install_package('jq','mcp_12345678')['ok']
    assert br.calls[-1][0]=='package.install'
    with pytest.raises(ValueError): b.install_package('-oBad=1','mcp_12345678')


def test_summary_flags_offline_service(tmp_path):
    br=FakeBroker()
    def call(action, params=None, session_key='session-default'):
        params=params or {}
        if action=='service.status':
            active='failed' if params.get('service')=='node' else 'active'
            return {'ok':True,'unit':'x.service','output':f'ActiveState={active}\nSubState=running\n','error':None}
        if action=='admin.nodes.list': return {'ok':True,'data':{'nodes':[]},'error':None}
        if action=='update.check': return {'ok':True,'output':'{"app":"core","code":"UP_TO_DATE"}\n','error':None}
        return {'ok':True}
    br.call=call
    b=backend(tmp_path,broker=br)
    out=b.privanet_summary()
    assert out['overall']=='ATTENTION' and any('node' in w for w in out['warnings'])


def test_system_health_bounded_paths(tmp_path):
    out=backend(tmp_path).system_health(); assert out['ok'] and str(tmp_path) in out['disks']


def test_redaction():
    clean=redact('Authorization: Bearer abc123 token=xyz password: hunter2')
    assert all(x not in clean for x in ['abc123','xyz','hunter2'])


def test_deploy_separates_shell_and_broker_identities():
    text=Path('deploy.sh').read_text()
    assert 'privanet-chat-broker' in text and 'privanet-chat-shell' in text and 'privanet-shell' in text
    assert 'SupplementaryGroups=$BROKER_GROUP $SHELL_GROUP' in text
    assert 'User=$SHELL_USER' in text


def test_shell_service_source_has_no_privileged_broker_socket():
    text=Path('agent/shell.py').read_text()
    assert 'privanet-chat-admin/broker.sock' not in text
    assert 'sudo' not in text


def test_broker_has_no_arbitrary_root_command_action():
    text=Path('agent/broker.py').read_text()
    assert 'root.shell' not in text
    assert 'package.install' in text
    assert 'systemd-run' in text


def test_versions_are_031():
    assert 'VERSION = "0.3.1"' in Path('agent/core.py').read_text()
    assert 'VERSION=0.3.1' in Path('deploy.sh').read_text()
    assert json.loads(Path('plugin/plugin.json').read_text())['version']=='0.3.1'


def test_deploy_migrates_existing_audit_ownership():
    text=Path('deploy.sh').read_text()
    assert 'chown "$SERVICE_USER:$SERVICE_GROUP" "$STATE_DIR"/audit.sqlite3*' in text
    assert 'BROKER_STATE_DIR=${BROKER_STATE_DIR:-/var/lib/privanet-chat-admin-broker}' in text


def test_broker_authorization_once_is_consumed(tmp_path, monkeypatch):
    import agent.broker as broker
    monkeypatch.setattr(broker, 'STATE_DB', str(tmp_path/'broker.sqlite3'))
    session='mcp_12345678'
    prep=broker.handle({'action':'auth.prepare','params':{'scope':'privanet.services','reason':'restart'},'session_key':session})
    grant=broker.handle({'action':'auth.grant','params':{'request_id':prep['requestId'],'duration':'once'},'session_key':session})
    assert grant['usesRemaining']==1
    assert broker._active_lease('privanet.services',session,consume=True) is not None
    assert broker._active_lease('privanet.services',session,consume=False) is None


def test_broker_timed_lease_and_revoke(tmp_path, monkeypatch):
    import agent.broker as broker
    monkeypatch.setattr(broker, 'STATE_DB', str(tmp_path/'broker.sqlite3'))
    session='mcp_abcdefgh'
    prep=broker.handle({'action':'auth.prepare','params':{'scope':'privanet.nodes','reason':'maintenance'},'session_key':session})
    broker.handle({'action':'auth.grant','params':{'request_id':prep['requestId'],'duration':'15m'},'session_key':session})
    status=broker.handle({'action':'auth.status','params':{},'session_key':session})
    assert status['leases'][0]['scope']=='privanet.nodes'
    revoked=broker.handle({'action':'auth.revoke_all','params':{},'session_key':session})
    assert revoked['revoked']==1
    assert broker.handle({'action':'auth.status','params':{},'session_key':session})['leases']==[]


def test_broker_denies_privileged_action_without_lease(tmp_path, monkeypatch):
    import agent.broker as broker
    monkeypatch.setattr(broker, 'STATE_DB', str(tmp_path/'broker.sqlite3'))
    with pytest.raises(PermissionError):
        broker.handle({'action':'service.restart','params':{'service':'node'},'session_key':'mcp_12345678'})


def test_broker_rejects_replayed_authorization_request(tmp_path, monkeypatch):
    import agent.broker as broker
    monkeypatch.setattr(broker, 'STATE_DB', str(tmp_path/'broker.sqlite3'))
    session='mcp_12345678'
    prep=broker.handle({'action':'auth.prepare','params':{'scope':'privanet.updates','reason':'updates'},'session_key':session})
    broker.handle({'action':'auth.grant','params':{'request_id':prep['requestId'],'duration':'once'},'session_key':session})
    with pytest.raises(PermissionError):
        broker.handle({'action':'auth.grant','params':{'request_id':prep['requestId'],'duration':'once'},'session_key':session})



def test_backend_denial_and_confirmation_calls_are_brokered(tmp_path):
    br=FakeBroker()
    br.set('auth.deny',{'ok':True,'denied':True,'scope':'privanet.services'})
    br.set('confirm.prepare',{'ok':True,'requestId':'confirm_req_x','action':'package.install','target':'jq'})
    br.set('confirm.grant',{'ok':True,'action':'package.install','target':'jq','usesRemaining':1})
    br.set('confirm.deny',{'ok':True,'denied':True,'action':'package.install','target':'jq'})
    b=backend(tmp_path,broker=br)
    assert b.deny_authorization('req_x','mcp_12345678')['denied'] is True
    prep=b.prepare_confirmation('package.install','jq','install jq','mcp_12345678')
    assert prep['requestId']=='confirm_req_x'
    assert b.grant_confirmation(prep['requestId'],'mcp_12345678')['usesRemaining']==1
    assert b.deny_confirmation('confirm_req_y','mcp_12345678')['denied'] is True


def test_unknown_confirmation_action_rejected(tmp_path):
    with pytest.raises(ValueError):
        backend(tmp_path).prepare_confirmation('root.shell','anything','bad','mcp_12345678')


def test_server_uses_mcp_app_and_has_no_elicitation():
    text=Path('agent/server.py').read_text()
    assert 'Apps()' in text
    assert 'ui://privanet-admin/approval-v1.html' in text
    assert 'visibility=["app"]' in text
    assert 'request_admin_access' in text and 'request_action_confirmation' in text
    assert 'context.elicit' not in text and '.elicit(' not in text
    assert 'privanet-shell account' in text


def test_skill_requires_card_then_retry():
    text=Path('plugin/skills/privanet-admin/SKILL.md').read_text()
    assert 'AUTHORIZATION_REQUIRED' in text
    assert 'request_admin_access' in text
    assert 'DESTRUCTIVE_CONFIRMATION_REQUIRED' in text
    assert 'request_action_confirmation' in text


def test_broker_denial_consumes_auth_request(tmp_path, monkeypatch):
    import agent.broker as broker
    monkeypatch.setattr(broker, 'STATE_DB', str(tmp_path/'broker.sqlite3'))
    session='mcp_12345678'
    prep=broker.handle({'action':'auth.prepare','params':{'scope':'privanet.services','reason':'restart'},'session_key':session})
    denied=broker.handle({'action':'auth.deny','params':{'request_id':prep['requestId']},'session_key':session})
    assert denied['denied'] is True
    with pytest.raises(PermissionError):
        broker.handle({'action':'auth.grant','params':{'request_id':prep['requestId'],'duration':'15m'},'session_key':session})


def test_broker_authorization_request_is_session_bound(tmp_path, monkeypatch):
    import agent.broker as broker
    monkeypatch.setattr(broker, 'STATE_DB', str(tmp_path/'broker.sqlite3'))
    prep=broker.handle({'action':'auth.prepare','params':{'scope':'privanet.services','reason':'restart'},'session_key':'mcp_sessionA'})
    with pytest.raises(PermissionError):
        broker.handle({'action':'auth.grant','params':{'request_id':prep['requestId'],'duration':'15m'},'session_key':'mcp_sessionB'})


def test_confirmation_requires_corresponding_scope(tmp_path, monkeypatch):
    import agent.broker as broker
    monkeypatch.setattr(broker, 'STATE_DB', str(tmp_path/'broker.sqlite3'))
    with pytest.raises(broker.AuthorizationRequired):
        broker.handle({'action':'confirm.prepare','params':{'action':'package.install','target':'jq','reason':'install'},'session_key':'mcp_12345678'})


def test_confirmation_request_is_session_bound_and_single_use(tmp_path, monkeypatch):
    import agent.broker as broker
    monkeypatch.setattr(broker, 'STATE_DB', str(tmp_path/'broker.sqlite3'))
    session='mcp_12345678'
    auth=broker.handle({'action':'auth.prepare','params':{'scope':'system.packages','reason':'packages'},'session_key':session})
    broker.handle({'action':'auth.grant','params':{'request_id':auth['requestId'],'duration':'15m'},'session_key':session})
    prep=broker.handle({'action':'confirm.prepare','params':{'action':'package.install','target':'jq','reason':'install jq'},'session_key':session})
    with pytest.raises(PermissionError):
        broker.handle({'action':'confirm.grant','params':{'request_id':prep['requestId']},'session_key':'mcp_other123'})
    granted=broker.handle({'action':'confirm.grant','params':{'request_id':prep['requestId']},'session_key':session})
    assert granted['usesRemaining']==1
    with pytest.raises(PermissionError):
        broker.handle({'action':'confirm.grant','params':{'request_id':prep['requestId']},'session_key':session})


def test_destructive_revoke_preserves_once_lease_until_confirmed(tmp_path, monkeypatch):
    import agent.broker as broker
    monkeypatch.setattr(broker, 'STATE_DB', str(tmp_path/'broker.sqlite3'))
    session='mcp_12345678'
    node_id='node_1234567890abcdef'

    def fake_admin(args, timeout=60):
        if args[:2]==['nodes','show']:
            return {'ok':True,'code':0,'stdout':json.dumps({'nodeId':node_id,'status':'ONLINE'}),'stderr':''}
        if args[:2]==['nodes','revoke']:
            return {'ok':True,'code':0,'stdout':'revoked','stderr':''}
        raise AssertionError(args)
    monkeypatch.setattr(broker, '_admin', fake_admin)

    auth=broker.handle({'action':'auth.prepare','params':{'scope':'privanet.nodes','reason':'revoke'},'session_key':session})
    broker.handle({'action':'auth.grant','params':{'request_id':auth['requestId'],'duration':'once'},'session_key':session})

    with pytest.raises(broker.ConfirmationRequired):
        broker.handle({'action':'admin.node.revoke','params':{'node_reference':node_id},'session_key':session})
    assert broker._active_lease('privanet.nodes',session,consume=False) is not None

    prep=broker.handle({'action':'confirm.prepare','params':{'action':'admin.node.revoke','target':node_id,'reason':'confirmed revoke'},'session_key':session})
    broker.handle({'action':'confirm.grant','params':{'request_id':prep['requestId']},'session_key':session})
    result=broker.handle({'action':'admin.node.revoke','params':{'node_reference':node_id},'session_key':session})
    assert result['ok'] is True
    assert broker._active_lease('privanet.nodes',session,consume=False) is None
    assert broker._active_confirmation('admin.node.revoke',node_id,session,consume=False) is None


def test_confirmation_target_must_match_exactly(tmp_path, monkeypatch):
    import agent.broker as broker
    monkeypatch.setattr(broker, 'STATE_DB', str(tmp_path/'broker.sqlite3'))
    session='mcp_12345678'
    auth=broker.handle({'action':'auth.prepare','params':{'scope':'system.packages','reason':'packages'},'session_key':session})
    broker.handle({'action':'auth.grant','params':{'request_id':auth['requestId'],'duration':'15m'},'session_key':session})
    prep=broker.handle({'action':'confirm.prepare','params':{'action':'package.install','target':'jq','reason':'install jq'},'session_key':session})
    broker.handle({'action':'confirm.grant','params':{'request_id':prep['requestId']},'session_key':session})
    assert broker._active_confirmation('package.install','curl',session,consume=False) is None
    assert broker._active_confirmation('package.install','jq',session,consume=False) is not None
