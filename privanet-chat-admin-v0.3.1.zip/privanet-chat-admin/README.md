# PrivaNet Chat Admin v0.3.1

PrivaNet Chat Admin is a private MCP server for administering a PrivaNet deployment from ChatGPT. v0.3 keeps the three-process privilege boundary introduced in 0.3.0 and v0.3.1 replaces server-initiated MCP elicitation with a transport-safe inline MCP App approval card.

## v0.3.1 changes

- **Inline approval card:** `request_admin_access` is now an MCP App tool linked to `ui://privanet-admin/approval-v1.html`. The card offers **this action only / 15 min / 30 min / 1 hour** and explicit Deny/Approve controls.
- **No server-initiated elicitation:** privileged operations no longer depend on `context.elicit`, which failed on transports without a server-to-client back-channel.
- **App-only grant/deny helpers:** the approval card calls `grant_admin_access` / `deny_admin_access`; those helpers are marked app-only and the model-visible request tool cannot grant access by itself.
- **Sensitive-action card:** node revocation and package installation use a second one-action confirmation card through `request_action_confirmation`.
- **Broker-enforced confirmations:** destructive confirmations are session-bound, target-bound, expire after five minutes, are single-use, and cannot be replayed.
- **One-shot lease preservation:** an `once` admin lease is not consumed just because a destructive operation discovers that a second confirmation is needed. It is consumed only when the confirmed action actually runs.
- **Denial consumes requests:** denied authorization/confirmation request IDs cannot later be replayed.
- **Fallback improved:** the root-only `privanet-chat-admin-authorize` helper can grant either a scoped lease or a one-action destructive confirmation for clients without MCP App UI.
- **Correct shell identity wording:** documentation/tool descriptions now consistently say `run_command` executes as `privanet-shell`, not `privanet-chat`.

## v0.3 security architecture

```text
ChatGPT / MCP client
        |
        v
privanet-chat-admin.service
user: privanet-chat
        |
        +------------------------------+
        |                              |
        v                              v
privanet-chat-shell.service      privanet-chat-admin-broker.service
user: privanet-shell             user: root
unprivileged commands            typed privileged operations only
        |                              |
        | cannot access                | checks scoped lease
        | broker socket                | + action/target confirmation
        v                              v
host diagnostics                 PrivaNet/system maintenance
```

The MCP frontend is allowed to reach the shell and broker sockets. The shell account is **not** a member of the broker group, so a command executed by `run_command` cannot mint leases or invoke privileged broker operations directly. Executable releases, systemd units, the broker database, and privileged credentials remain root-owned.

## Authorization flow

A normal privileged request works like this:

1. A privileged tool checks the current MCP session for the required scope.
2. If missing, it returns `AUTHORIZATION_REQUIRED` with the exact scope/reason and does nothing.
3. ChatGPT calls `request_admin_access`, which prepares a five-minute request and renders the inline approval card.
4. Only the card's app-only Approve action can turn that prepared request into a scoped lease.
5. ChatGPT retries the original operation after approval.
6. The root broker independently checks the active lease and allowlisted operation.

Scopes:

| Scope | Allows |
| --- | --- |
| `privanet.services` | Restart allowlisted Priva services |
| `privanet.nodes` | Approve/deny/rename/revoke nodes |
| `privanet.node_local` | Change local node slot settings |
| `privanet.updates` | Apply verified Priva application updates |
| `system.packages` | Install one validated package from configured APT repositories |

`revoke_admin_access` immediately removes all leases for the current MCP session.

### Sensitive-action confirmation

Node revocation and package installation require an additional one-action confirmation even when their broader scope is already active:

1. The broker verifies the required scope without consuming an `once` lease.
2. If the exact action/target lacks confirmation, the tool returns `DESTRUCTIVE_CONFIRMATION_REQUIRED` without making the change.
3. ChatGPT calls `request_action_confirmation`, which displays a separate inline confirmation card.
4. Approval creates a five-minute, one-use confirmation tied to the same MCP session, action, and exact target.
5. Retrying the operation consumes both the one-use confirmation and, if applicable, the one-shot scope lease.

## Fallback authorization

If a client cannot render the MCP App card, a root operator can grant a scope locally after obtaining the current MCP session key from `get_authorization_status`:

```bash
privanet-chat-admin-authorize privanet.services \
  --session mcp_... \
  --duration 30m \
  --reason 'maintenance session'
```

The same root-only helper can grant a one-action confirmation after the corresponding scope is already active:

```bash
privanet-chat-admin-authorize \
  --session mcp_... \
  --confirm-action admin.node.revoke \
  --target node_... \
  --reason 'operator confirmed node revocation'
```

This is a fallback only. Normal ChatGPT usage should use the inline card.

## Command sandbox

`run_command` executes non-interactive commands as `privanet-shell`, never root. It has no password, no sudo, no access to the broker socket, a sanitized environment, bounded execution/output, its own writable work directory, `ProtectSystem=strict`, and `ProtectHome=true`.

Typical diagnostic uses include:

```bash
uptime
free -h
ss -lntp
ps aux
du -sh /var/lib/privasearch
curl http://127.0.0.1:4020/health
```

## Privileged broker

The root broker accepts fixed structured actions, not arbitrary root commands. Current privileged actions cover allowlisted service restarts, node approve/deny/rename/revoke, local slot changes, verified Priva updates, and validated Debian package installation. There is no `sudo ALL`, arbitrary root shell, arbitrary root filesystem writer, SSH-management tool, or user-management tool.

## Node and diagnostic tools

v0.3 also provides:

- `get_privanet_summary`
- `get_command_environment`
- `run_command`
- `get_nodes(include_revoked=...)`
- `get_node`
- `diagnose_node`
- `get_node_version_drift`
- `rename_node`
- `get_privasearch_summary`
- `get_update_history`
- cleaner fresh `get_update_status`
- combined frontend/broker audit reporting

Remote nodes can be inspected and diagnosed. The current Core coordinator still does not expose a safe central operation for changing another node's local slot/resource policy, so v0.3.1 does not fake that capability with SSH.

## Install / upgrade

From an extracted release:

```bash
cd privanet-chat-admin
sudo ./deploy.sh
```

The deploy script automatically creates/migrates the locked system identities and groups:

```text
privanet-chat             MCP frontend, no login
privanet-shell            command sandbox, no login
privanet-chat-broker      broker-client group
privanet-chat-shell       shell-client group
```

Services:

```text
privanet-chat-admin.service
privanet-chat-admin-broker.service
privanet-chat-shell.service
privanet-chat-admin-update-check.service
```

The MCP endpoint remains `http://127.0.0.1:8787/mcp`; the existing OpenAI Secure MCP Tunnel can continue pointing to it.

## Easy updates

```bash
privanet-chat-admin-update --check
privanet-chat-admin-update
```

The updater reads `https://doopydoop364.github.io/privanet-chat-admin-latest.json`, verifies origin and SHA-256, extracts the release, and runs `deploy.sh`. Existing configuration is backed up and merged with new defaults.

## Model-visible MCP tools

### Overall / diagnostics

- `get_privanet_summary`
- `get_services`
- `get_service_status`
- `get_recent_logs`
- `get_system_health`
- `get_command_environment`
- `run_command`
- `get_audit_log`

### Authorization / confirmation

- `get_authorization_status`
- `request_admin_access` — renders the inline access card
- `request_action_confirmation` — renders the one-action confirmation card
- `revoke_admin_access`

Grant/deny helpers used by the card are app-only and should not be model-visible.

### Nodes

- `get_nodes`
- `get_node`
- `diagnose_node`
- `get_node_version_drift`
- `get_pending_nodes`
- `approve_node`
- `deny_node`
- `rename_node`
- `revoke_node`
- `get_local_node_slots`
- `set_local_node_slots`
- `clear_local_node_slots`

### PrivaSearch

- `get_privasearch_health`
- `get_privasearch_status`
- `get_privasearch_summary`

### Updates / host maintenance

- `get_update_status`
- `get_update_history`
- `get_update_schedule`
- `apply_available_updates`
- `restart_service`
- `install_system_package`

## Validation

```bash
python -m pytest -q
bash -n deploy.sh
bash -n update.sh
python -m compileall -q agent authorize.py
python -m json.tool agent/config.example.json >/dev/null
python -m json.tool plugin/plugin.json >/dev/null
```

The regression suite covers shell/broker identity separation, lease creation/expiry/one-shot consumption, session binding, denial/replay protection, destructive action/target confirmation, service allowlisting, node tools, updater parsing, PrivaSearch summaries, package-name validation, and the absence of arbitrary root-shell broker actions.
