from __future__ import annotations

import json
import os
import secrets
import weakref
from typing import Any, Literal

from mcp.server import MCPServer
from mcp.server.mcpserver.context import Context
from pydantic import BaseModel, Field

from .core import AdminBackend, BrokerError, SCOPES, VERSION

CONFIG_PATH = os.environ.get("PRIVANET_CHAT_ADMIN_CONFIG", "/etc/privanet-chat-admin/config.json")
with open(CONFIG_PATH, "r", encoding="utf-8") as fh:
    config = json.load(fh)
backend = AdminBackend(config)

mcp = MCPServer(
    "PrivaNet Admin",
    version=VERSION,
    instructions=(
        "Conversational administration for PrivaNet. Read-only diagnostics are available without elevation. "
        "run_command always executes as the locked-down privanet-chat Unix account with a sanitized environment. "
        "Never imply a command or privileged action succeeded unless the returned result says ok=true. "
        "When a privileged tool needs access, use the host-native authorization prompt and honor denial/cancel. "
        "Privileges are scoped and short-lived; no arbitrary root shell is exposed. Destructive actions require an extra confirmation."
    ),
)

_SESSION_KEYS: weakref.WeakKeyDictionary[Any, str] = weakref.WeakKeyDictionary()


def _session_key(context: Context[Any, Any]) -> str:
    session = context.request_context.session
    try:
        key = _SESSION_KEYS.get(session)
        if key is None:
            key = "mcp_" + secrets.token_hex(16)
            _SESSION_KEYS[session] = key
        return key
    except TypeError:
        return "mcp_" + format(id(session), "x")


class ApprovalForm(BaseModel):
    approve: bool = Field(default=False, title="Approve access", description="Turn this on to approve the requested PrivaNet administrative access.")
    duration: Literal["once", "15m", "30m", "60m"] = Field(
        default="once",
        title="Duration",
        description="Choose one action or a short timed authorization lease.",
        json_schema_extra={
            "oneOf": [
                {"const": "once", "title": "This action only"},
                {"const": "15m", "title": "15 minutes"},
                {"const": "30m", "title": "30 minutes"},
                {"const": "60m", "title": "1 hour"},
            ]
        },
    )


class ConfirmForm(BaseModel):
    confirm: bool = Field(default=False, title="Confirm action", description="This action has additional consequences and needs a separate confirmation.")


async def _ensure_scope(context: Context[Any, Any], scope: str, reason: str) -> tuple[bool, dict[str, Any]]:
    session_key = _session_key(context)
    status = backend.authorization_status(session_key)
    if any(lease.get("scope") == scope for lease in status.get("leases", [])):
        return True, {"authorization": "existing", "scope": scope}
    prepared = backend.prepare_authorization(scope, reason, session_key)
    try:
        result = await context.elicit(
            message=(
                f"PrivaNet Admin requests temporary permission: {scope}.\n\n"
                f"Reason: {reason}\n\n"
                f"Allows: {SCOPES[scope]}\n"
                "The shell remains unprivileged and no general root shell is enabled."
            ),
            schema=ApprovalForm,
        )
    except Exception as exc:
        return False, {
            "ok": False,
            "code": "AUTHORIZATION_PROMPT_UNAVAILABLE",
            "scope": scope,
            "reason": reason,
            "message": "The MCP client did not complete the interactive approval prompt.",
            "detail": str(exc)[:300],
        }
    if result.action != "accept" or not result.data.approve:
        return False, {"ok": False, "code": "AUTHORIZATION_DENIED", "scope": scope, "reason": reason}
    granted = backend.grant_authorization(prepared["requestId"], result.data.duration, session_key)
    return True, {"authorization": "granted", **granted}


async def _confirm(context: Context[Any, Any], message: str) -> bool:
    try:
        result = await context.elicit(message=message, schema=ConfirmForm)
    except Exception:
        return False
    return result.action == "accept" and bool(result.data.confirm)


@mcp.tool()
def get_privanet_summary() -> dict[str, Any]:
    """One-call operator summary: services, nodes, PrivaSearch, updates, host capacity, and warnings."""
    return backend.privanet_summary()


@mcp.tool()
def get_services() -> list[dict[str, Any]]:
    """List health/status for every allowlisted Priva service."""
    return backend.list_services()


@mcp.tool()
def get_service_status(service: str) -> dict[str, Any]:
    """Get detailed systemd status for one allowlisted Priva service."""
    return backend.service_status(service)


@mcp.tool()
def get_recent_logs(service: str, lines: int = 100, priority: str | None = None) -> dict[str, Any]:
    """Read a bounded, redacted slice of logs from one allowlisted service through the root broker."""
    return backend.recent_logs(service, lines, priority)


@mcp.tool()
def get_system_health() -> dict[str, Any]:
    """Show homeserver uptime, load, memory and disk capacity."""
    return backend.system_health()


@mcp.tool()
def get_command_environment() -> dict[str, Any]:
    """Describe the locked-down Unix account and restrictions used by run_command."""
    return backend.command_environment()


@mcp.tool()
def run_command(command: str, timeout_seconds: int = 20) -> dict[str, Any]:
    """Run a non-interactive shell command as the unprivileged privanet-chat account. This never becomes root."""
    return backend.run_command(command, timeout_seconds)


@mcp.tool()
def get_nodes(include_revoked: bool = True) -> dict[str, Any]:
    """List enrolled nodes. Set include_revoked=false to hide revoked nodes."""
    return backend.list_nodes(include_revoked)


@mcp.tool()
def get_node(node_reference: str) -> dict[str, Any]:
    """Show detailed coordinator telemetry for one node by ID, unique prefix, or exact name."""
    return backend.get_node(node_reference)


@mcp.tool()
def diagnose_node(node_reference: str) -> dict[str, Any]:
    """Explain visible health problems for one node using coordinator telemetry."""
    return backend.diagnose_node(node_reference)


@mcp.tool()
def get_node_version_drift() -> dict[str, Any]:
    """Group active nodes by daemon version and report whether versions differ."""
    return backend.version_drift()


@mcp.tool()
def get_pending_nodes(include_all: bool = False) -> dict[str, Any]:
    """List pending join requests; include_all also returns historical requests."""
    return backend.list_pending_nodes(include_all)


@mcp.tool()
def get_audit_log(limit: int = 50) -> list[dict[str, Any]]:
    """Return recent shell, bridge, authorization, and privileged-broker audit records."""
    return backend.audit_recent(limit)


@mcp.tool()
def get_authorization_status(context: Context[Any, Any]) -> dict[str, Any]:
    """Show active scoped authorization leases for this MCP session."""
    return backend.authorization_status(_session_key(context))


@mcp.tool()
def revoke_admin_access(context: Context[Any, Any]) -> dict[str, Any]:
    """Immediately revoke all temporary administrative authorization for this MCP session."""
    return backend.revoke_authorization(_session_key(context))


@mcp.tool()
async def request_admin_access(scope: Literal["privanet.services", "privanet.nodes", "privanet.node_local", "privanet.updates", "system.packages"], reason: str, context: Context[Any, Any]) -> dict[str, Any]:
    """Open the host-native permission prompt for a scoped temporary admin lease without performing an action."""
    ok, info = await _ensure_scope(context, scope, reason)
    return {"ok": ok, **info}


@mcp.tool()
def get_local_node_slots() -> dict[str, Any]:
    """Show the saved/default job-slot setting for the local node when readable without elevation."""
    return backend.local_node_slots()


@mcp.tool()
def get_privasearch_health() -> dict[str, Any]:
    """Read PrivaSearch /health."""
    return backend.privasearch_health()


@mcp.tool()
def get_privasearch_status() -> dict[str, Any]:
    """Read authenticated PrivaSearch operator /status through the root broker without exposing its token."""
    return backend.privasearch_status()


@mcp.tool()
def get_privasearch_summary() -> dict[str, Any]:
    """Return a concise crawler/index summary: queue, throughput, quality, concentration and warnings."""
    return backend.privasearch_summary()


@mcp.tool()
def get_update_status() -> dict[str, Any]:
    """Run a fresh verified update check and return the latest per-app events only."""
    return backend.check_updates()


@mcp.tool()
def get_update_history(limit: int = 100) -> dict[str, Any]:
    """Read bounded historical logs from the Priva application updater."""
    return backend.update_history(limit)


@mcp.tool()
def get_update_schedule() -> dict[str, Any]:
    """Show the systemd schedule/state for the automatic Priva updater."""
    return backend.updater_schedule()


@mcp.tool()
async def restart_service(service: str, context: Context[Any, Any]) -> dict[str, Any]:
    """Restart one allowlisted Priva service after scoped interactive approval if needed."""
    ok, auth = await _ensure_scope(context, "privanet.services", f"Restart {service}")
    if not ok:
        return auth
    try:
        result = backend.restart_service(service, _session_key(context))
    except BrokerError as exc:
        return {"ok": False, "code": exc.code, "error": str(exc)}
    result["authorization"] = auth
    return result


@mcp.tool()
async def apply_available_updates(context: Context[Any, Any]) -> dict[str, Any]:
    """Install verified Priva updates after scoped interactive approval if needed."""
    ok, auth = await _ensure_scope(context, "privanet.updates", "Install verified Priva application updates; services may restart")
    if not ok:
        return auth
    result = backend.apply_updates(_session_key(context))
    result["authorization"] = auth
    return result


@mcp.tool()
async def approve_node(request_code: str, capabilities: list[str], context: Context[Any, Any], label: str | None = None) -> dict[str, Any]:
    """Approve a pending node with explicit capabilities after scoped approval if needed."""
    ok, auth = await _ensure_scope(context, "privanet.nodes", f"Approve pending node request {request_code}")
    if not ok:
        return auth
    result = backend.approve_node(request_code, capabilities, label, _session_key(context))
    result["authorization"] = auth
    return result


@mcp.tool()
async def deny_node(request_code: str, context: Context[Any, Any]) -> dict[str, Any]:
    """Deny a pending node request after scoped approval if needed."""
    ok, auth = await _ensure_scope(context, "privanet.nodes", f"Deny pending node request {request_code}")
    if not ok:
        return auth
    result = backend.deny_node(request_code, _session_key(context))
    result["authorization"] = auth
    return result


@mcp.tool()
async def rename_node(node_reference: str, context: Context[Any, Any], name: str | None = None, clear: bool = False) -> dict[str, Any]:
    """Rename an enrolled node, or clear its display name, after scoped approval if needed."""
    ok, auth = await _ensure_scope(context, "privanet.nodes", f"Rename node {node_reference}")
    if not ok:
        return auth
    result = backend.rename_node(node_reference, name, clear, _session_key(context))
    result["authorization"] = auth
    return result


@mcp.tool()
async def revoke_node(node_reference: str, context: Context[Any, Any]) -> dict[str, Any]:
    """Revoke a node. This always requires both node-admin authorization and a separate destructive confirmation."""
    ok, auth = await _ensure_scope(context, "privanet.nodes", f"Administer enrolled node {node_reference}")
    if not ok:
        return auth
    if not await _confirm(context, f"Revoke node {node_reference}? This invalidates its credentials and hands back leased jobs."):
        return {"ok": False, "code": "DESTRUCTIVE_ACTION_CANCELLED", "node_reference": node_reference}
    result = backend.revoke_node(node_reference, _session_key(context))
    result["authorization"] = auth
    return result


@mcp.tool()
async def set_local_node_slots(slots: int, context: Context[Any, Any]) -> dict[str, Any]:
    """Save a local job-slot override after scoped approval if needed."""
    ok, auth = await _ensure_scope(context, "privanet.node_local", f"Set local node job slots to {slots}")
    if not ok:
        return auth
    result = backend.set_local_node_slots(slots, _session_key(context))
    result["authorization"] = auth
    return result


@mcp.tool()
async def clear_local_node_slots(context: Context[Any, Any]) -> dict[str, Any]:
    """Clear the local job-slot override after scoped approval if needed."""
    ok, auth = await _ensure_scope(context, "privanet.node_local", "Clear the local node job-slot override")
    if not ok:
        return auth
    result = backend.clear_local_node_slots(_session_key(context))
    result["authorization"] = auth
    return result


@mcp.tool()
async def install_system_package(package: str, context: Context[Any, Any]) -> dict[str, Any]:
    """Install one validated Debian package from configured APT repositories. Requires scope plus per-action confirmation."""
    ok, auth = await _ensure_scope(context, "system.packages", f"Install Debian package {package}")
    if not ok:
        return auth
    if not await _confirm(context, f"Install system package '{package}' as root using apt-get? Package maintainer scripts run with root privileges."):
        return {"ok": False, "code": "DESTRUCTIVE_ACTION_CANCELLED", "package": package}
    result = backend.install_package(package, _session_key(context))
    result["authorization"] = auth
    return result


app = mcp.streamable_http_app()
