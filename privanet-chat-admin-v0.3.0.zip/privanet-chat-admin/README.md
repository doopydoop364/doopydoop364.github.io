# PrivaNet Chat Admin v0.3.0

PrivaNet Chat Admin is a private MCP server for administering a PrivaNet deployment from ChatGPT. v0.3.0 adds a real privilege boundary: ChatGPT gets a useful command shell, but that shell is permanently unprivileged; operations requiring root go through a separate broker and require explicit, scoped, short-lived user authorization.

## v0.3 highlights

- **Sandboxed command execution:** `run_command` executes as the locked `privanet-shell` Unix account with a sanitized environment, bounded timeout/output, no login password, no sudo, and no access to the privileged broker socket.
- **Host-native permission prompts:** privileged tools use MCP elicitation so ChatGPT can present an approval form with **this action only / 15 min / 30 min / 1 hour** choices.
- **Scoped leases:** permissions are separated into `privanet.services`, `privanet.nodes`, `privanet.node_local`, `privanet.updates`, and `system.packages`.
- **No arbitrary root shell:** elevation only unlocks typed broker actions. `run_command` never changes identity or privilege.
- **Destructive confirmations:** node revocation and system package installation require a second action-specific confirmation even when a broader lease is already active.
- **Three-process isolation:** the MCP frontend, command sandbox, and root broker use separate Unix users/groups and separate Unix sockets.
- **Node operator tools:** detailed node lookup, revoked-node filtering, diagnosis, rename support, and daemon-version drift reporting.
- **One-call health summary:** `get_privanet_summary` combines service, node, PrivaSearch, update, disk, memory, and warning state.
- **Cleaner updater view:** a fresh update check returns current per-app events; historical updater logs are a separate tool.
- **PrivaSearch summary:** concise queue, throughput, quality, concentration, and warning output.
- **Combined audit trail:** shell activity, authorization events, and privileged broker operations are auditable.

## Privilege architecture

```text
ChatGPT / MCP client
        |
        v
privanet-chat-admin.service
user: privanet-chat
        |
        +------------------------------+
        |                              |
        v                              v
privanet-chat-shell.service      privanet-chat-admin-broker.service
user: privanet-shell             user: root
unprivileged commands            typed privileged operations only
        |                              |
        | cannot access                | checks scoped lease
        | broker socket                | + allowlisted target
        v                              v
read-only host inspection        PrivaNet/system maintenance
```

The MCP frontend is a member of two client groups so it can reach both helper sockets. The shell account is **not** a member of the broker group. Consequently, a command executed by `run_command` cannot mint a lease or call privileged broker operations directly.

The broker's lease database is kept in a root-only state directory separate from the MCP frontend's writable audit/work state.

## Authorization flow

A typical privileged request works like this:

1. Chat Admin checks whether the current MCP session already has the required scope.
2. If not, it asks the broker to create a short-lived authorization request.
3. The tool triggers an MCP form elicitation. ChatGPT can render this as a native permission prompt.
4. Only an accepted prompt with `approve=true` creates a lease.
5. The broker checks the lease and the exact requested operation.
6. A one-action lease is consumed after one privileged operation; timed leases expire automatically.

Scopes:

| Scope | Allows |
| --- | --- |
| `privanet.services` | Restart allowlisted Priva services |
| `privanet.nodes` | Approve/deny/rename/revoke nodes |
| `privanet.node_local` | Change local node slot settings |
| `privanet.updates` | Apply verified Priva application updates |
| `system.packages` | Install one validated package from configured APT repositories |

`revoke_admin_access` immediately removes all leases for the current MCP session.

### Fallback approval

If a client cannot render MCP elicitation, a root operator can grant a scope locally after retrieving the current MCP session key with `get_authorization_status`:

```bash
privanet-chat-admin-authorize privanet.services \
  --session mcp_... \
  --duration 30m \
  --reason 'maintenance session'
```

This is a fallback only; normal ChatGPT usage should use the inline approval prompt.

## Command sandbox

`run_command` is intended for natural diagnostics such as:

```bash
uptime
free -h
ss -lntp
ps aux
find /opt/privanet -maxdepth 2 -type f
curl http://127.0.0.1:4020/health
```

The command sandbox:

- runs as `privanet-shell`, never root;
- has no password and `/usr/sbin/nologin` as its login shell;
- receives only a small environment (`PATH`, `LANG`, `HOME`, `TMPDIR`);
- has a private writable work directory under `/var/lib/privanet-chat-shell`;
- sees the rest of the system through a `ProtectSystem=strict` systemd sandbox;
- cannot access home directories through `ProtectHome=true`;
- cannot reach the privileged broker Unix socket;
- has bounded execution time and output size;
- redacts common credential patterns before command output reaches the model.

## Privileged broker

The root broker does **not** accept arbitrary command strings. It exposes fixed actions for:

- reading allowlisted service status/logs;
- read-only PrivaNet admin node/request queries;
- authenticated PrivaSearch status without returning the token;
- restarting allowlisted Priva services;
- node approve/deny/rename/revoke;
- local node slot set/clear;
- verified Priva updater check/apply;
- validated APT package installation after explicit confirmation.

Executable releases and systemd units remain root-owned. There is no `sudo ALL`, arbitrary root shell, arbitrary root file-write tool, or user-management tool.

## Install / upgrade

From an extracted release:

```bash
cd privanet-chat-admin
sudo ./deploy.sh
```

The deploy script creates/migrates:

```text
privanet-chat             MCP frontend, no login
privanet-shell            command sandbox, no login
privanet-chat-broker      broker-client group
privanet-chat-shell       shell-client group
```

Services:

```text
privanet-chat-admin.service
privanet-chat-admin-broker.service
privanet-chat-shell.service
privanet-chat-admin-update-check.service
```

The MCP endpoint remains:

```text
http://127.0.0.1:8787/mcp
```

OpenAI Secure MCP Tunnel can continue pointing at that same endpoint.

## Easy updates

v0.3 keeps the existing self-updater:

```bash
privanet-chat-admin-update --check
privanet-chat-admin-update
```

It reads `https://doopydoop364.github.io/privanet-chat-admin-latest.json`, validates the manifest origin and SHA-256, extracts the release, and runs `deploy.sh`. Existing configuration is merged with new defaults and backed up before replacement.

## MCP tools

### Overall / diagnostic

- `get_privanet_summary`
- `get_services`
- `get_service_status`
- `get_recent_logs`
- `get_system_health`
- `get_command_environment`
- `run_command`
- `get_audit_log`

### Authorization

- `get_authorization_status`
- `request_admin_access`
- `revoke_admin_access`

### Nodes

- `get_nodes(include_revoked=...)`
- `get_node`
- `diagnose_node`
- `get_node_version_drift`
- `get_pending_nodes`
- `approve_node`
- `deny_node`
- `rename_node`
- `revoke_node`
- `get_local_node_slots`
- `set_local_node_slots`
- `clear_local_node_slots`

The current Core coordinator still does not provide a safe central API for changing arbitrary remote nodes' local resource-policy/slot configuration. v0.3 therefore reports and diagnoses remote nodes but does not fake remote slot control. Local slot changes remain brokered on the homeserver.

### PrivaSearch

- `get_privasearch_health`
- `get_privasearch_status`
- `get_privasearch_summary`

### Updates / host maintenance

- `get_update_status`
- `get_update_history`
- `get_update_schedule`
- `apply_available_updates`
- `restart_service`
- `install_system_package`

## Security notes

- Chat Admin remains localhost-only.
- No API/admin secret is placed in the MCP frontend or shell environment.
- The root broker reads root-only PrivaNet/PrivaSearch credentials only when required and returns redacted/structured results.
- Approval leases are session-scoped when the MCP host maintains a stable session object and always have a hard expiration.
- Host-native approval is an application security control, not a cryptographic proof from ChatGPT to root. The broker still independently limits what an active lease can authorize.
- Package installation is intentionally stronger than normal PrivaNet administration: it is a separate scope and always gets an additional confirmation because Debian package maintainer scripts execute as root.

## Validation

```bash
python -m pytest -q
bash -n deploy.sh
bash -n update.sh
python -m compileall -q agent authorize.py
python -m json.tool agent/config.example.json >/dev/null
python -m json.tool plugin/plugin.json >/dev/null
```

The test suite covers shell/broker identity separation, command limits/redaction, service allowlisting, node diagnostics and mutation mappings, authorization state, update parsing, PrivaSearch summaries, package-name validation, deployment identity separation, and absence of an arbitrary root-shell action.
