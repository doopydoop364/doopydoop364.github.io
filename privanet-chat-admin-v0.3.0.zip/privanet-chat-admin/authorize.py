#!/usr/bin/env python3
"""Root-only fallback authorization utility for clients without MCP elicitation UI."""
from __future__ import annotations
import argparse, json, os, socket, sys

SOCKET = "/run/privanet-chat-admin/broker.sock"

def call(action, params, session_key):
    payload = json.dumps({"action": action, "params": params, "session_key": session_key}) + "\n"
    with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as s:
        s.connect(SOCKET); s.sendall(payload.encode()); data=b""
        while b"\n" not in data:
            c=s.recv(65536)
            if not c: break
            data += c
    return json.loads(data.split(b"\n",1)[0])

def main():
    if os.geteuid() != 0:
        print("Run as root.", file=sys.stderr); return 1
    p=argparse.ArgumentParser()
    p.add_argument("scope", choices=["privanet.services","privanet.nodes","privanet.node_local","privanet.updates","system.packages"])
    p.add_argument("--session", required=True, help="MCP session key shown by get_authorization_status")
    p.add_argument("--duration", choices=["once","15m","30m","60m"], default="once")
    p.add_argument("--reason", default="Local operator approval")
    a=p.parse_args()
    prep=call("auth.prepare", {"scope":a.scope,"reason":a.reason}, a.session)
    if not prep.get("ok"):
        print(json.dumps(prep)); return 1
    req=prep["result"]["requestId"]
    grant=call("auth.grant", {"request_id":req,"duration":a.duration}, a.session)
    print(json.dumps(grant, indent=2)); return 0 if grant.get("ok") else 1
if __name__ == "__main__": raise SystemExit(main())
