from pathlib import Path

import pytest

from agent.core import AdminBackend, CommandResult, redact


class FakeRunner:
    def __init__(self):
        self.calls = []
        self.responses = []

    def queue(self, result):
        self.responses.append(result)

    def run(self, argv):
        self.calls.append(argv)
        if self.responses:
            return self.responses.pop(0)
        return CommandResult(True, 0, "{}", "")


def cfg(tmp_path: Path):
    return {
        "audit_db": str(tmp_path / "audit.sqlite3"),
        "local_node_state_dir": "/var/lib/privanet-node",
        "managed_services": {"coordinator": "privanet-coordinator.service"},
        "executables": {
            "privanet_admin": "/usr/local/bin/privanet-admin",
            "privanet_node": "/opt/privanet-node/current/bin/privanet-node",
        },
        "limits": {"max_log_lines": 50, "max_job_slots": 16, "command_timeout_seconds": 1},
    }


def test_service_allowlist(tmp_path):
    b = AdminBackend(cfg(tmp_path), FakeRunner())
    with pytest.raises(ValueError):
        b.restart_service("sshd")


def test_restart_is_exact_systemctl_argv(tmp_path):
    r = FakeRunner()
    b = AdminBackend(cfg(tmp_path), r)
    out = b.restart_service("coordinator")
    assert out["ok"] is True
    assert r.calls == [["systemctl", "restart", "privanet-coordinator.service"]]


def test_pending_uses_current_requests_cli(tmp_path):
    r = FakeRunner()
    b = AdminBackend(cfg(tmp_path), r)
    b.list_pending_nodes()
    assert r.calls[-1] == ["/usr/local/bin/privanet-admin", "requests", "list", "--json"]


def test_approve_requires_explicit_capability_and_uses_current_cli(tmp_path):
    r = FakeRunner()
    b = AdminBackend(cfg(tmp_path), r)
    b.approve_node("ABCD-EF12", ["web.fetch.v1"], "crawler")
    assert r.calls[-1] == [
        "/usr/local/bin/privanet-admin", "approve", "ABCD-EF12",
        "--capabilities", "web.fetch.v1", "--label", "crawler", "--json"
    ]
    with pytest.raises(ValueError):
        b.approve_node("ABCD-EF12", [])


def test_revoke_uses_nodes_revoke_and_rejects_option_injection(tmp_path):
    r = FakeRunner()
    b = AdminBackend(cfg(tmp_path), r)
    b.revoke_node("node_12345678")
    assert r.calls[-1] == ["/usr/local/bin/privanet-admin", "nodes", "revoke", "node_12345678"]
    with pytest.raises(ValueError):
        b.revoke_node("--help")


def test_local_job_slots_are_absolute_and_bounded(tmp_path):
    r = FakeRunner()
    b = AdminBackend(cfg(tmp_path), r)
    b.set_local_node_slots(8)
    assert r.calls[-1] == [
        "/opt/privanet-node/current/bin/privanet-node", "slots", "set", "8", "--json", "--state-dir", "/var/lib/privanet-node"
    ]
    with pytest.raises(ValueError):
        b.set_local_node_slots(17)


def test_local_job_slots_show_and_clear(tmp_path):
    r = FakeRunner()
    b = AdminBackend(cfg(tmp_path), r)
    b.local_node_slots()
    assert r.calls[-1][1:4] == ["slots", "show", "--json"]
    b.clear_local_node_slots()
    assert r.calls[-1][1:4] == ["slots", "clear", "--json"]


def test_log_line_limit(tmp_path):
    r = FakeRunner()
    r.queue(CommandResult(True, 0, "hello", ""))
    b = AdminBackend(cfg(tmp_path), r)
    b.recent_logs("coordinator", 500)
    assert "50" in r.calls[-1]


def test_redaction():
    text = "Authorization: Bearer abc123 token=xyz password: hunter2"
    clean = redact(text)
    assert "abc123" not in clean
    assert "xyz" not in clean
    assert "hunter2" not in clean
