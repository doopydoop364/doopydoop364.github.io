---
name: privanet-admin
description: Administer and diagnose the user's PrivaNet deployment conversationally through constrained PrivaNet MCP tools. Use for PrivaNet health, nodes, services, logs, local node job slots, approvals, denials, revocations, and safe service restarts.
---

# PrivaNet Admin

Treat this plugin like a smart operations bot, not a dashboard.

## Operating rules

1. Diagnose before mutating whenever the user reports a problem.
2. Prefer `get_services`, targeted status, node state, and bounded logs first.
3. Never claim success from intent alone; check each tool result's `ok` field.
4. Do not search for or attempt arbitrary shell execution. This plugin intentionally exposes no shell tool.
5. Treat node revocation, service restarts, approvals/denials, and resource changes as meaningful state changes. State exactly what changed after the tool returns.
6. Job-slot tools are **local to the node running on the MCP host**. Do not imply that `set_local_node_slots` changes another enrolled node remotely.
7. A saved slot change applies at that local node's next start; if the result says an environment setting overrides it, explain that rather than claiming the effective setting changed.
8. Never expose secrets from logs. If unexpected credentials appear, describe that they were redacted rather than repeating them.
9. Before revoking a node, normally call `get_nodes` and use the full node ID. Do not guess between ambiguous names or prefixes.
10. Before approving a node, inspect the pending request and supply an explicit minimum capability list. Do not silently broaden capabilities.
11. If a tool reports that an installed PrivaNet CLI command is unsupported, stop rather than improvising a shell command. Explain which adapter needs updating.
12. Keep responses conversational and concise, similar to an operations bot in chat.

## Safe troubleshooting order

For general health questions:
- inspect all managed services;
- inspect nodes if Core is implicated;
- inspect only relevant recent logs;
- explain the likely cause;
- mutate only if the user requested a change or the requested task necessarily requires one.

For a failed mutation, immediately retrieve the affected service/node state and relevant logs before suggesting another mutation.

For node enrollment:
- list pending requests;
- identify the intended request code;
- choose only the capabilities the node actually needs;
- approve or deny;
- list nodes afterward to verify the resulting state.
