from __future__ import annotations

import json
import os
from typing import Any

from mcp.server import MCPServer

from .core import AdminBackend

CONFIG_PATH = os.environ.get("PRIVANET_CHAT_ADMIN_CONFIG", "/etc/privanet-chat-admin/config.json")
with open(CONFIG_PATH, "r", encoding="utf-8") as fh:
    config = json.load(fh)
backend = AdminBackend(config)

mcp = MCPServer(
    "PrivaNet Admin",
    instructions=(
        "Conversational administration for PrivaNet. Prefer read-only diagnosis before mutation. "
        "Never imply a command succeeded unless the returned result says ok=true. "
        "Mutating tools affect only allowlisted PrivaNet components; there is no arbitrary shell tool. "
        "Job-slot tools affect only the node running on this same machine."
    ),
)


@mcp.tool()
def get_services() -> list[dict[str, Any]]:
    """List health/status for every allowlisted PrivaNet service."""
    return backend.list_services()


@mcp.tool()
def get_service_status(service: str) -> dict[str, Any]:
    """Get detailed systemd status for one allowlisted PrivaNet service."""
    return backend.service_status(service)


@mcp.tool()
def get_recent_logs(service: str, lines: int = 100, priority: str | None = None) -> dict[str, Any]:
    """Read a bounded, redacted slice of logs from one allowlisted service."""
    return backend.recent_logs(service, lines, priority)


@mcp.tool()
def get_nodes() -> dict[str, Any]:
    """List enrolled PrivaNet nodes using the installed privanet-admin CLI."""
    return backend.list_nodes()


@mcp.tool()
def get_pending_nodes(include_all: bool = False) -> dict[str, Any]:
    """List pending PrivaNet join requests; include_all also returns historical requests."""
    return backend.list_pending_nodes(include_all)


@mcp.tool()
def get_audit_log(limit: int = 50) -> list[dict[str, Any]]:
    """Return recent admin actions recorded by this bridge."""
    return backend.audit_recent(limit)


@mcp.tool()
def get_local_node_slots() -> dict[str, Any]:
    """Show the job-slot setting for the PrivaNet node on this same host."""
    return backend.local_node_slots()


@mcp.tool()
def restart_service(service: str) -> dict[str, Any]:
    """Restart one allowlisted PrivaNet service. This is a mutating admin operation."""
    return backend.restart_service(service)


@mcp.tool()
def approve_node(request_code: str, capabilities: list[str], label: str | None = None) -> dict[str, Any]:
    """Approve a pending join request with an explicit capability allowlist and optional label."""
    return backend.approve_node(request_code, capabilities, label)


@mcp.tool()
def deny_node(request_code: str) -> dict[str, Any]:
    """Deny a pending node join request by request code."""
    return backend.deny_node(request_code)


@mcp.tool()
def revoke_node(node_reference: str) -> dict[str, Any]:
    """Revoke an enrolled node. Prefer a full node ID obtained from get_nodes before calling."""
    return backend.revoke_node(node_reference)


@mcp.tool()
def set_local_node_slots(slots: int) -> dict[str, Any]:
    """Save an absolute job-slot setting for the node on this host. It applies on next node start."""
    return backend.set_local_node_slots(slots)


@mcp.tool()
def clear_local_node_slots() -> dict[str, Any]:
    """Clear the saved local job-slot override so normal defaults/environment take effect."""
    return backend.clear_local_node_slots()


app = mcp.streamable_http_app()
