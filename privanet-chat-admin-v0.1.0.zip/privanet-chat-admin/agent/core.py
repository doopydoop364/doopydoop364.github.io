from __future__ import annotations

import json
import re
import sqlite3
import subprocess
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

SECRET_PATTERNS = [
    re.compile(r"(?i)(authorization:\s*bearer\s+)[^\s]+"),
    re.compile(r"(?i)(token|secret|password|api[_-]?key)(\s*[=:]\s*)[^\s,;]+"),
]


def redact(text: str) -> str:
    out = text
    for pattern in SECRET_PATTERNS:
        if pattern.groups >= 2:
            out = pattern.sub(lambda m: f"{m.group(1)}{m.group(2)}[REDACTED]", out)
        else:
            out = pattern.sub(lambda m: f"{m.group(1)}[REDACTED]", out)
    return out


@dataclass(frozen=True)
class CommandResult:
    ok: bool
    code: int
    stdout: str
    stderr: str


class Runner:
    def __init__(self, timeout: int = 20):
        self.timeout = timeout

    def run(self, argv: list[str]) -> CommandResult:
        proc = subprocess.run(
            argv,
            text=True,
            capture_output=True,
            timeout=self.timeout,
            check=False,
            env={"PATH": "/usr/sbin:/usr/bin:/sbin:/bin"},
        )
        return CommandResult(
            ok=proc.returncode == 0,
            code=proc.returncode,
            stdout=redact(proc.stdout[-20000:]),
            stderr=redact(proc.stderr[-12000:]),
        )


class AuditLog:
    def __init__(self, db_path: str):
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        self.db_path = db_path
        with sqlite3.connect(self.db_path) as db:
            db.execute(
                """
                CREATE TABLE IF NOT EXISTS audit (
                  id INTEGER PRIMARY KEY AUTOINCREMENT,
                  ts INTEGER NOT NULL,
                  action TEXT NOT NULL,
                  target TEXT,
                  args_json TEXT NOT NULL,
                  ok INTEGER NOT NULL,
                  summary TEXT NOT NULL
                )
                """
            )

    def write(self, action: str, target: str | None, args: dict[str, Any], ok: bool, summary: str) -> None:
        safe_args = {
            k: ("[REDACTED]" if any(s in k.lower() for s in ("token", "secret", "password", "key")) else v)
            for k, v in args.items()
        }
        with sqlite3.connect(self.db_path) as db:
            db.execute(
                "INSERT INTO audit(ts,action,target,args_json,ok,summary) VALUES(?,?,?,?,?,?)",
                (int(time.time()), action, target, json.dumps(safe_args, sort_keys=True), int(ok), redact(summary)[:4000]),
            )

    def recent(self, limit: int = 50) -> list[dict[str, Any]]:
        limit = max(1, min(limit, 200))
        with sqlite3.connect(self.db_path) as db:
            rows = db.execute(
                "SELECT ts,action,target,args_json,ok,summary FROM audit ORDER BY id DESC LIMIT ?",
                (limit,),
            ).fetchall()
        return [
            {
                "ts": row[0],
                "action": row[1],
                "target": row[2],
                "args": json.loads(row[3]),
                "ok": bool(row[4]),
                "summary": row[5],
            }
            for row in rows
        ]


class AdminBackend:
    """Allowlisted PrivaNet administration. No generic shell execution exists."""

    def __init__(self, config: dict[str, Any], runner: Runner | None = None):
        self.config = config
        self.services: dict[str, str] = config.get("managed_services", {})
        executables = config.get("executables", {})
        self.admin_bin = executables.get("privanet_admin", "/usr/local/bin/privanet-admin")
        self.node_bin = executables.get("privanet_node", "/opt/privanet-node/current/bin/privanet-node")
        self.node_state_dir = config.get("local_node_state_dir", "/var/lib/privanet-node")
        limits = config.get("limits", {})
        self.max_log_lines = int(limits.get("max_log_lines", 300))
        self.max_job_slots = int(limits.get("max_job_slots", 32))
        self.runner = runner or Runner(int(limits.get("command_timeout_seconds", 20)))
        self.audit = AuditLog(config.get("audit_db", "/var/lib/privanet-chat-admin/audit.sqlite3"))

    @staticmethod
    def _json_or_text(result: CommandResult) -> Any:
        if not result.ok:
            return None
        try:
            return json.loads(result.stdout)
        except json.JSONDecodeError:
            return result.stdout

    @staticmethod
    def _node_reference(reference: str) -> str:
        value = reference.strip()
        # Current privanet-admin accepts an exact node ID/name or a unique 8+ char ID prefix.
        # Keep the bridge stricter than the CLI: printable, bounded, no control chars or option-like input.
        if not value or len(value) > 160 or value.startswith("-") or not re.fullmatch(r"[A-Za-z0-9_.:@+\- ]+", value):
            raise ValueError("Invalid node reference")
        return value

    @staticmethod
    def _request_code(request_code: str) -> str:
        value = request_code.strip().upper().replace(" ", "-")
        if not re.fullmatch(r"[A-Z0-9]{4}-?[A-Z0-9]{4}", value):
            raise ValueError("Invalid request code format")
        if "-" not in value:
            value = f"{value[:4]}-{value[4:]}"
        return value

    @staticmethod
    def _capabilities(capabilities: list[str]) -> list[str]:
        if not capabilities:
            raise ValueError("At least one capability is required")
        clean: list[str] = []
        for capability in capabilities:
            value = capability.strip()
            if not re.fullmatch(r"[a-z0-9][a-z0-9._-]{0,95}", value):
                raise ValueError(f"Invalid capability: {capability}")
            if value not in clean:
                clean.append(value)
        return clean

    def _service(self, name: str) -> str:
        try:
            return self.services[name]
        except KeyError:
            raise ValueError(f"Unknown managed service: {name}") from None

    def service_status(self, name: str) -> dict[str, Any]:
        unit = self._service(name)
        result = self.runner.run([
            "systemctl", "show", unit, "--no-page",
            "--property=ActiveState,SubState,MainPID,ExecMainStatus,ActiveEnterTimestamp",
        ])
        data: dict[str, str] = {}
        for line in result.stdout.splitlines():
            if "=" in line:
                k, v = line.split("=", 1)
                data[k] = v
        return {"service": name, "unit": unit, "ok": result.ok, "state": data, "error": result.stderr or None}

    def list_services(self) -> list[dict[str, Any]]:
        return [self.service_status(name) for name in sorted(self.services)]

    def recent_logs(self, name: str, lines: int = 100, priority: str | None = None) -> dict[str, Any]:
        unit = self._service(name)
        lines = max(1, min(int(lines), self.max_log_lines))
        argv = ["journalctl", "-u", unit, "-n", str(lines), "--no-pager", "--output=short-iso"]
        if priority:
            allowed = {"emerg", "alert", "crit", "err", "warning", "notice", "info", "debug"}
            if priority not in allowed:
                raise ValueError("Unsupported journal priority")
            argv += ["-p", priority]
        result = self.runner.run(argv)
        return {"service": name, "ok": result.ok, "logs": result.stdout, "error": result.stderr or None}

    def restart_service(self, name: str) -> dict[str, Any]:
        unit = self._service(name)
        result = self.runner.run(["systemctl", "restart", unit])
        self.audit.write("restart_service", name, {}, result.ok, result.stderr or "restart requested")
        return {"service": name, "ok": result.ok, "error": result.stderr or None}

    def list_nodes(self) -> dict[str, Any]:
        result = self.runner.run([self.admin_bin, "nodes", "list", "--json"])
        return {"ok": result.ok, "nodes": self._json_or_text(result), "error": result.stderr or None}

    def list_pending_nodes(self, include_all: bool = False) -> dict[str, Any]:
        argv = [self.admin_bin, "requests", "list"]
        if include_all:
            argv.append("--all")
        argv.append("--json")
        result = self.runner.run(argv)
        return {"ok": result.ok, "pending": self._json_or_text(result), "error": result.stderr or None}

    def approve_node(self, request_code: str, capabilities: list[str], label: str | None = None) -> dict[str, Any]:
        code = self._request_code(request_code)
        caps = self._capabilities(capabilities)
        argv = [self.admin_bin, "approve", code, "--capabilities", ",".join(caps)]
        if label is not None:
            clean_label = label.strip()
            if not clean_label or len(clean_label) > 80 or any(ord(ch) < 32 for ch in clean_label):
                raise ValueError("Invalid node label")
            argv += ["--label", clean_label]
        argv.append("--json")
        result = self.runner.run(argv)
        self.audit.write(
            "approve_node", code, {"capabilities": caps, "label": label}, result.ok, result.stderr or result.stdout
        )
        return {
            "ok": result.ok,
            "request_code": code,
            "capabilities": caps,
            "label": label,
            "output": self._json_or_text(result),
            "error": result.stderr or None,
        }

    def deny_node(self, request_code: str) -> dict[str, Any]:
        code = self._request_code(request_code)
        result = self.runner.run([self.admin_bin, "deny", code, "--json"])
        self.audit.write("deny_node", code, {}, result.ok, result.stderr or result.stdout)
        return {"ok": result.ok, "request_code": code, "output": self._json_or_text(result), "error": result.stderr or None}

    def revoke_node(self, node_reference: str) -> dict[str, Any]:
        reference = self._node_reference(node_reference)
        result = self.runner.run([self.admin_bin, "nodes", "revoke", reference])
        self.audit.write("revoke_node", reference, {}, result.ok, result.stderr or result.stdout)
        return {"ok": result.ok, "node_reference": reference, "output": result.stdout, "error": result.stderr or None}

    def local_node_slots(self) -> dict[str, Any]:
        result = self.runner.run([
            self.node_bin, "slots", "show", "--json", "--state-dir", self.node_state_dir
        ])
        return {"ok": result.ok, "slots": self._json_or_text(result), "error": result.stderr or None}

    def set_local_node_slots(self, slots: int) -> dict[str, Any]:
        slots = int(slots)
        if slots < 1 or slots > self.max_job_slots:
            raise ValueError(f"slots must be between 1 and {self.max_job_slots}")
        result = self.runner.run([
            self.node_bin, "slots", "set", str(slots), "--json", "--state-dir", self.node_state_dir
        ])
        parsed = self._json_or_text(result)
        self.audit.write("set_local_node_slots", "local-node", {"slots": slots}, result.ok, result.stderr or result.stdout)
        return {
            "ok": result.ok,
            "slots": slots,
            "result": parsed,
            "note": "The saved slot count applies at the node's next start and PRIVANODE_JOB_SLOTS, if set, takes priority.",
            "error": result.stderr or None,
        }

    def clear_local_node_slots(self) -> dict[str, Any]:
        result = self.runner.run([
            self.node_bin, "slots", "clear", "--json", "--state-dir", self.node_state_dir
        ])
        self.audit.write("clear_local_node_slots", "local-node", {}, result.ok, result.stderr or result.stdout)
        return {"ok": result.ok, "result": self._json_or_text(result), "error": result.stderr or None}

    def audit_recent(self, limit: int = 50) -> list[dict[str, Any]]:
        return self.audit.recent(limit)
