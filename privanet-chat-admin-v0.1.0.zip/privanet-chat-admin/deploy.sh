#!/usr/bin/env bash
set -euo pipefail

PREFIX=${PREFIX:-/opt/privanet-chat-admin}
CONFIG_DIR=${CONFIG_DIR:-/etc/privanet-chat-admin}
STATE_DIR=${STATE_DIR:-/var/lib/privanet-chat-admin}

if [[ $EUID -ne 0 ]]; then
  echo "Run as root." >&2
  exit 1
fi

install -d -m 0755 "$PREFIX" "$CONFIG_DIR"
install -d -o root -g root -m 0700 "$STATE_DIR"

python3 -m venv "$PREFIX/venv"
"$PREFIX/venv/bin/pip" install --upgrade pip
"$PREFIX/venv/bin/pip" install 'mcp>=2,<3' 'pydantic>=2.10,<3' 'uvicorn>=0.30,<1'

install -d -m 0755 "$PREFIX/app/agent"
install -m 0644 agent/__init__.py agent/core.py agent/server.py "$PREFIX/app/agent/"

if [[ ! -e "$CONFIG_DIR/config.json" ]]; then
  install -m 0600 -o root -g root agent/config.example.json "$CONFIG_DIR/config.json"
  echo "Created $CONFIG_DIR/config.json; review executable paths and service names before starting."
fi

cat > /etc/systemd/system/privanet-chat-admin.service <<UNIT
[Unit]
Description=PrivaNet conversational admin MCP service (LOCALHOST ONLY)
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=root
Group=root
WorkingDirectory=$PREFIX/app
Environment=PYTHONPATH=$PREFIX/app
Environment=PRIVANET_CHAT_ADMIN_CONFIG=$CONFIG_DIR/config.json
ExecStart=$PREFIX/venv/bin/uvicorn agent.server:app --host 127.0.0.1 --port 8787
Restart=on-failure
RestartSec=5
NoNewPrivileges=true
PrivateTmp=true
ProtectHome=true
ProtectSystem=strict
ReadWritePaths=$STATE_DIR
ProtectKernelTunables=true
ProtectKernelModules=true
ProtectControlGroups=true
RestrictRealtime=true
LockPersonality=true
RestrictSUIDSGID=true

[Install]
WantedBy=multi-user.target
UNIT

systemctl daemon-reload
echo "Installed. Review $CONFIG_DIR/config.json, then run: systemctl enable --now privanet-chat-admin"
