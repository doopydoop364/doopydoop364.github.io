# PrivaNet Chat Admin v0.1.0

A conversational, constrained administration bridge for PrivaNet. It is intentionally designed like a smart operations bot rather than a dashboard.

## What V0.1 is

The project has two layers:

1. **Home-server MCP agent** — a small Streamable HTTP MCP service that translates explicit tools into existing PrivaNet/systemd operations.
2. **ChatGPT plugin package** — a skill that teaches ChatGPT how to diagnose first, choose safe tools, and report exactly what changed.

The MCP process binds to localhost only. A production ChatGPT connection still needs a real authenticated HTTPS MCP endpoint. Do not expose the localhost service directly to the public Internet.

## Security model

- Binds only to `127.0.0.1:8787` by default.
- Exposes explicit MCP tools; **no arbitrary shell tool exists**.
- Subprocesses are invoked with exact argv arrays (`shell=False`).
- Service control is restricted to a root-owned allowlist.
- Node references, join codes, labels, capabilities, log priorities, line counts, and slot counts are validated/bounded.
- Log reads are bounded and common credential patterns are redacted.
- Mutations are written to a local SQLite audit log.
- Job-slot changes are absolute/idempotent and capped by config.
- Node approval requires an explicit capability list; the bridge does not silently grant a default capability.
- V0.1 deliberately contains no wipe/reset/delete-state tools.
- The public layer must use OAuth 2.1-compatible MCP authorization (or another client-supported OAuth layer) before ChatGPT is connected.

The service runs as root in V0.1 because the current PrivaNet admin wrapper reads the root-owned coordinator environment and service restart/log operations require host privileges. The attack surface is kept narrow through the tool allowlist and systemd sandboxing. A future version can split privileged operations behind a smaller root helper.

## Components

- `agent/core.py` — allowlisted system/PrivaNet adapter and audit layer.
- `agent/server.py` — Streamable HTTP MCP server.
- `agent/config.example.json` — root-owned allowlists, executable paths, state path, and limits.
- `plugin/` — Agent Plugins package source and conversational skill.
- `deploy.sh` — Debian/systemd deployment helper.
- `tests/` — unit tests for the security boundary and current PrivaNet CLI mappings.

## Install on the homeserver

Copy this directory to the server, review `agent/config.example.json`, then as root:

```bash
./deploy.sh
nano /etc/privanet-chat-admin/config.json
systemctl enable --now privanet-chat-admin
systemctl status privanet-chat-admin
```

The default executable paths are based on the current PrivaNet layout but are configurable. Verify them on the actual homeserver before starting the service.

Local MCP URL:

```text
http://127.0.0.1:8787/mcp
```

## Current PrivaNet Core adapter

V0.1 is aligned to the current Core CLI shape:

- `privanet-admin nodes list --json`
- `privanet-admin requests list [--all] --json`
- `privanet-admin approve CODE --capabilities ... [--label ...] --json`
- `privanet-admin deny CODE --json`
- `privanet-admin nodes revoke NODE`
- `privanet-node slots show|set N|clear --json --state-dir DIR`

### Important: job slots are local

The current Core coordinator admin CLI does **not** centrally set another node's job slots. Slot configuration lives in each node's local control state. Therefore V0.1 exposes `get_local_node_slots`, `set_local_node_slots`, and `clear_local_node_slots` only for the node running on the same machine as this MCP agent.

A saved slot change applies the next time that node starts. If `PRIVANODE_JOB_SLOTS` is set in the node's environment, that environment value takes priority.

To control remote nodes' local settings later, install a narrowly scoped agent on each node or add a purpose-built authenticated coordinator-to-node control protocol. Do not fake this with remote arbitrary shell execution.

## V0.1 MCP tools

Read-only:

- `get_services`
- `get_service_status`
- `get_recent_logs`
- `get_nodes`
- `get_pending_nodes`
- `get_audit_log`
- `get_local_node_slots`

Mutating:

- `restart_service`
- `approve_node`
- `deny_node`
- `revoke_node`
- `set_local_node_slots`
- `clear_local_node_slots`

## Authentication and public connection

The local agent is **not a public endpoint**. To connect it to ChatGPT, publish `/mcp` at a stable HTTPS URL and protect it with MCP-compatible OAuth 2.1.

A production MCP resource server should reject unauthenticated requests, advertise RFC 9728 protected-resource metadata, and validate bearer tokens issued by the configured authorization server. The current MCP Python SDK supports this via `AuthSettings` plus a `TokenVerifier` (or an authorization-server provider).

Once the authenticated endpoint exists, create `plugin/mcp.json` from `plugin/mcp.json.example`, replacing the example URL with the real endpoint:

```json
{
  "$schema": "https://agent-plugins.org/schemas/1.0.0/mcp.schema.json",
  "mcpServers": {
    "privanet-admin": {
      "type": "streamable-http",
      "url": "https://admin.example.net/mcp"
    }
  }
}
```

Do not put a permanent bearer token or other secret into `mcp.json`.

## Validation

Run:

```bash
python -m pytest -q
```

The V0.1 source bundle currently passes the included unit tests for command mapping, input rejection, service allowlisting, slot bounds, log bounds, and secret redaction.

Full MCP transport/auth integration must be validated on a host with the MCP SDK installed and with the final HTTPS/OAuth endpoint configured.
